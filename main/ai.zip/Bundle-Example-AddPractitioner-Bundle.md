# Example-AddPractitioner-Bundle - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-AddPractitioner-Bundle**

## Example Bundle: Example-AddPractitioner-Bundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Example-AddPractitioner-Bundle",
  "meta" : {
    "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-bundle"]
  },
  "type" : "collection",
  "entry" : [{
    "fullUrl" : "urn:uuid:67b11c73-c2ee-474f-ab64-56b863a1cc87",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "Example-AddPractitioner-Practitioner",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_Example-AddPractitioner-Practitioner\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner Example-AddPractitioner-Practitioner</b></p><a name=\"Example-AddPractitioner-Practitioner\"> </a><a name=\"hcExample-AddPractitioner-Practitioner\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-practitioner.html\">BCPractitioner</a></p></div><blockquote><p><b>BC License Status Extension</b></p><ul><li>statusCode: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-code-system SUSPENDED}\">Suspended</span></li><li>statusReasonCode: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-reason-code-system LTP}\">Left the Province</span></li><li>statusClassCode: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-class-code-system LIC}\">Licensure</span></li><li>period: 2022-06-24 --&gt; (ongoing)</li></ul></blockquote><blockquote><p><b>BC Practitioner Disciplinary Actions Extension</b></p><ul><li>identifier: DA-1</li><li>description: Description</li><li>archiveDate: 2000-01-01</li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 1998-01-02 --&gt; (ongoing)</li><li>displayFlag: false</li></ul></blockquote><blockquote><p><b>BC Notes Extension</b></p><ul><li>identifier: <code>http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id</code>/Note-2</li><li>text: Note text</li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 1998-01-02 --&gt; (ongoing)</li></ul></blockquote><blockquote><p><b>BC Practitioner Conditions Extension</b></p><ul><li>identifier: <code>http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-condition-id</code>/Condition-1</li><li>restriction: false</li><li>restrictionText: Restriction text</li><li>code: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-condition-type-code-system EXP}\">EXP</span></li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 1998-01-02 --&gt; (ongoing)</li></ul></blockquote><blockquote><p><b>BC Confidentiality Extension</b></p><ul><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 2000-01-01 --&gt; 2020-01-01</li><li>code: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-Confidentiality R}\">restricted</span></li></ul></blockquote><p><b>BC Practitioner Date of Death Extension</b>: 2000-02-01</p><p><b>BC Valid Period Extension</b>: 2012-12-07 --&gt; (ongoing)</p><p><b>BC Birth Place Extension</b>: Ottawa ON CA </p><p><b>identifier</b>: <a href=\"NamingSystem-ca-bc-license-physician.html\" title=\"Physician ID Number\">CaBcLicensePhysician</a>/123454 (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>active</b>: true</p><p><b>name</b>: GivenName FamilyName (Official)</p><p><b>telecom</b>: ph: 2501112234</p><p><b>address</b>: 1000 DOUGLAS ST Kelowna BC V6P7B8 CA </p><p><b>gender</b>: Female</p><p><b>birthDate</b>: 1934-01-02</p><h3>Qualifications</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Code</b></td><td><b>Period</b></td><td><b>Issuer</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><span title=\"Codes:{http://fhir.infoway-inforoute.ca/CodeSystem/scpqual BD}\">CREDENTIAL_CREDENTIALDESIGNATIONTXT</span></td><td>2000-01-01 --&gt; 2020-01-01</td><td><a href=\"#hcExample-AddPractitioner-Practitioner/qualificationOrganization\">Organization CREDENTIAL_CREDENTIALGRANTINGINSTTXT</a></td></tr></table><p><b>communication</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-language-code-system B01}\">Bengali</span></p><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #qualificationOrganization</b></p><a name=\"Example-AddPractitioner-Practitioner/qualificationOrganization\"> </a><a name=\"hcExample-AddPractitioner-Practitioner/qualificationOrganization\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-organization.html\">BCOrganization</a></p></div><p><b>name</b>: CREDENTIAL_CREDENTIALGRANTINGINSTTXT</p><p><b>address</b>: CALGARY AB CA </p></blockquote></div>"
      },
      "contained" : [{
        "resourceType" : "Organization",
        "id" : "qualificationOrganization",
        "meta" : {
          "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization"]
        },
        "name" : "CREDENTIAL_CREDENTIALGRANTINGINSTTXT",
        "address" : [{
          "city" : "CALGARY",
          "state" : "AB",
          "country" : "CA"
        }]
      }],
      "extension" : [{
        "extension" : [{
          "url" : "statusCode",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-code-system",
              "code" : "SUSPENDED"
            }]
          }
        },
        {
          "url" : "statusReasonCode",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-reason-code-system",
              "code" : "LTP"
            }]
          }
        },
        {
          "url" : "statusClassCode",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-class-code-system",
              "code" : "LIC"
            }]
          }
        },
        {
          "url" : "period",
          "valuePeriod" : {
            "start" : "2022-06-24"
          }
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-license-status-extension"
      },
      {
        "extension" : [{
          "url" : "identifier",
          "valueIdentifier" : {
            "value" : "DA-1"
          }
        },
        {
          "url" : "description",
          "valueString" : "Description"
        },
        {
          "url" : "archiveDate",
          "valueDateTime" : "2000-01-01"
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "1998-01-02"
          }
        },
        {
          "url" : "displayFlag",
          "valueBoolean" : false
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-disciplinary-action-extension"
      },
      {
        "extension" : [{
          "url" : "identifier",
          "valueIdentifier" : {
            "system" : "http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id",
            "value" : "Note-2"
          }
        },
        {
          "url" : "text",
          "valueString" : "Note text"
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "1998-01-02"
          }
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-note-extension"
      },
      {
        "extension" : [{
          "url" : "identifier",
          "valueIdentifier" : {
            "system" : "http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-condition-id",
            "value" : "Condition-1"
          }
        },
        {
          "url" : "restriction",
          "valueBoolean" : false
        },
        {
          "url" : "restrictionText",
          "valueString" : "Restriction text"
        },
        {
          "url" : "code",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-condition-type-code-system",
              "code" : "EXP"
            }]
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "1998-01-02"
          }
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-condition-extension"
      },
      {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "2000-01-01",
            "end" : "2020-01-01"
          }
        },
        {
          "url" : "code",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
              "code" : "R"
            }]
          }
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-confidentiality-extension"
      },
      {
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-deathdate-extension",
        "valueDateTime" : "2000-02-01"
      },
      {
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
        "valuePeriod" : {
          "start" : "2012-12-07"
        }
      },
      {
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-birthplace-extension",
        "valueAddress" : {
          "city" : "Ottawa",
          "state" : "ON",
          "country" : "CA"
        }
      }],
      "identifier" : [{
        "system" : "https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-license-physician",
        "value" : "123454",
        "period" : {
          "start" : "2000-01-01"
        }
      }],
      "active" : true,
      "name" : [{
        "use" : "official",
        "family" : "FamilyName",
        "given" : ["GivenName"],
        "period" : {
          "start" : "2012-12-07"
        }
      }],
      "telecom" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
              "code" : "BC"
            }]
          }
        }],
        "system" : "phone",
        "value" : "2501112234",
        "period" : {
          "start" : "2000-02-02"
        }
      }],
      "address" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
              "code" : "BC"
            }]
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-address-validation-status-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-address-validation-status-code-system",
              "code" : "V"
            }]
          }
        }],
        "type" : "postal",
        "line" : ["1000 DOUGLAS ST"],
        "city" : "Kelowna",
        "state" : "BC",
        "postalCode" : "V6P7B8",
        "country" : "CA",
        "period" : {
          "start" : "2000-01-01"
        }
      }],
      "gender" : "female",
      "birthDate" : "1934-01-02",
      "_birthDate" : {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-birthtime-extension",
          "valueDateTime" : "1951-11-12T00:00:01-06:00"
        }]
      },
      "qualification" : [{
        "extension" : [{
          "extension" : [{
            "url" : "designation",
            "valueString" : "designation"
          },
          {
            "url" : "equivalencyFlag",
            "valueBoolean" : true
          },
          {
            "url" : "registrationNumber",
            "valueString" : "registration number"
          },
          {
            "url" : "issuedDate",
            "valueDateTime" : "2000-01-01"
          }],
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-qualification-extension"
        }],
        "code" : {
          "coding" : [{
            "system" : "http://fhir.infoway-inforoute.ca/CodeSystem/scpqual",
            "code" : "BD"
          }],
          "text" : "CREDENTIAL_CREDENTIALDESIGNATIONTXT"
        },
        "period" : {
          "start" : "2000-01-01",
          "end" : "2020-01-01"
        },
        "issuer" : {
          "reference" : "#qualificationOrganization"
        }
      }],
      "communication" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "2000-01-01"
          }
        }],
        "coding" : [{
          "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-language-code-system",
          "code" : "B01"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:f431631b-ed68-4716-80be-cca6904309fc",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "Example-PractitionerRole-Role-FromPrac-CPSID",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-role"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_Example-PractitionerRole-Role-FromPrac-CPSID\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole Example-PractitionerRole-Role-FromPrac-CPSID</b></p><a name=\"Example-PractitionerRole-Role-FromPrac-CPSID\"> </a><a name=\"hcExample-PractitionerRole-Role-FromPrac-CPSID\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-practitioner-role.html\">BCPractitionerRole</a></p></div><p><b>practitioner</b>: Identifier: <a href=\"NamingSystem-ca-bc-license-physician.html\" title=\"Physician ID Number\">CaBcLicensePhysician</a>/123454 (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>code</b>: <span title=\"Codes:{http://fhir.infoway-inforoute.ca/CodeSystem/scptype MD}\">MD</span></p><p><b>specialty</b>: <span title=\"Codes:{http://fhir.infoway-inforoute.ca/CodeSystem/scpqual AMD53}\">AMD53</span></p></div>"
      },
      "practitioner" : {
        "identifier" : {
          "system" : "https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-license-physician",
          "value" : "123454",
          "period" : {
            "start" : "2000-01-01"
          }
        }
      },
      "code" : [{
        "coding" : [{
          "system" : "http://fhir.infoway-inforoute.ca/CodeSystem/scptype",
          "code" : "MD"
        }]
      }],
      "specialty" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "2000-01-01",
            "end" : "2020-01-01"
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-specialty-source-extension",
          "valueString" : "Expertise source"
        }],
        "coding" : [{
          "system" : "http://fhir.infoway-inforoute.ca/CodeSystem/scpqual",
          "code" : "AMD53"
        }]
      }]
    }
  }]
}

```
