# Example-DistributePractitioner-Bundle-forTesting - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-DistributePractitioner-Bundle-forTesting**

## Example Bundle: Example-DistributePractitioner-Bundle-forTesting



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Example-DistributePractitioner-Bundle-forTesting",
  "meta" : {
    "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-bundle"]
  },
  "type" : "collection",
  "entry" : [{
    "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/Practitioner/IPC.00147699.BC.PRS",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "IPC.00147699.BC.PRS",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_IPC.00147699.BC.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner IPC.00147699.BC.PRS</b></p><a name=\"IPC.00147699.BC.PRS\"> </a><a name=\"hcIPC.00147699.BC.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-practitioner.html\">BCPractitioner</a></p></div><p><b>BC Valid Period Extension</b>: 2012-12-07 --&gt; (ongoing)</p><p><b>BC Owner Extension</b>: ?ngen-9?</p><p><b>BC Birth Place Extension</b>: Ottawa ON CA </p><p><b>identifier</b>: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147622.BC.PRS (, period: 2000-01-01 --&gt; (ongoing)), <a href=\"NamingSystem-ca-bc-plr-common-party-number.html\" title=\"Common Party Number\">CaBcPlrCommonPartyNumber</a>/CPN.00147422.BC.PRS (, period: 2000-01-01 --&gt; (ongoing)), <a href=\"NamingSystem-ca-bc-license-physician.html\" title=\"Physician ID Number\">CaBcLicensePhysician</a>/123454 (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>name</b>: GivenName FamilyName (Official)</p><p><b>gender</b>: Male</p><p><b>birthDate</b>: 1934-01-02</p></div>"
      },
      "extension" : [{
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
        "valuePeriod" : {
          "start" : "2012-12-07"
        }
      },
      {
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
        "valueIdentifier" : {
          "assigner" : {
            "display" : "MOH"
          }
        }
      },
      {
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-birthplace-extension",
        "valueAddress" : {
          "city" : "Ottawa",
          "state" : "ON",
          "country" : "CA"
        }
      }],
      "identifier" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        }],
        "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
        "value" : "IPC.00147622.BC.PRS",
        "period" : {
          "start" : "2000-01-01"
        }
      },
      {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        }],
        "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-common-party-number",
        "value" : "CPN.00147422.BC.PRS",
        "period" : {
          "start" : "2000-01-01"
        }
      },
      {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        }],
        "system" : "https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-license-physician",
        "value" : "123454",
        "period" : {
          "start" : "2000-01-01"
        }
      }],
      "name" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        }],
        "use" : "official",
        "family" : "FamilyName",
        "given" : ["GivenName"],
        "period" : {
          "start" : "2012-12-07"
        }
      }],
      "gender" : "male",
      "birthDate" : "1934-01-02",
      "_birthDate" : {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-birthtime-extension",
          "valueDateTime" : "1951-11-12T00:00:01-06:00"
        }]
      }
    }
  },
  {
    "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/IPC.00147699.BC.PRS",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "IPC.00147699.BC.PRS",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-role"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_IPC.00147699.BC.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole IPC.00147699.BC.PRS</b></p><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-practitioner-role.html\">BCPractitionerRole</a></p></div><p><b>practitioner</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-common-party-number.html\" title=\"Common Party Number\">CaBcPlrCommonPartyNumber</a>/CPN.00147422.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>code</b>: <span title=\"Codes:{http://fhir.infoway-inforoute.ca/CodeSystem/scptype MD}\">MD</span></p><p><b>specialty</b>: <span title=\"Codes:{http://fhir.infoway-inforoute.ca/CodeSystem/scpqual AMD53}\">AMD53</span></p></div>"
      },
      "practitioner" : {
        "identifier" : {
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
            "valueIdentifier" : {
              "assigner" : {
                "display" : "MOH"
              }
            }
          }],
          "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-common-party-number",
          "value" : "CPN.00147422.BC.PRS",
          "period" : {
            "start" : "2000-01-01"
          }
        }
      },
      "code" : [{
        "coding" : [{
          "system" : "http://fhir.infoway-inforoute.ca/CodeSystem/scptype",
          "code" : "MD"
        }]
      }],
      "specialty" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "2000-01-01",
            "end" : "2020-01-01"
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-specialty-source-extension",
          "valueString" : "Expertise source"
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        }],
        "coding" : [{
          "system" : "http://fhir.infoway-inforoute.ca/CodeSystem/scpqual",
          "code" : "AMD53"
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/RELN.153.PRS",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "RELN.153.PRS",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-role-relationships"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_RELN.153.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole RELN.153.PRS</b></p><a name=\"RELN.153.PRS\"> </a><a name=\"hcRELN.153.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-role-relationships.html\">BCRoleRelationships</a></p></div><p><b>BC Practitioner to Organization or Practitioner to Practitioner Type Extension.</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system EE}\">Employee</span></p><p><b>period</b>: 2000-01-01 --&gt; (ongoing)</p><p><b>practitioner</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147622.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>organization</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147436.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p></div>"
      },
      "extension" : [{
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-relationship-type-extension",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system",
            "code" : "EE"
          }]
        }
      }],
      "period" : {
        "start" : "2000-01-01"
      },
      "practitioner" : {
        "identifier" : {
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
            "valueIdentifier" : {
              "assigner" : {
                "display" : "MOH"
              }
            }
          }],
          "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
          "value" : "IPC.00147622.BC.PRS",
          "period" : {
            "start" : "2000-01-01"
          }
        }
      },
      "organization" : {
        "identifier" : {
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
            "valueIdentifier" : {
              "assigner" : {
                "display" : "MOH"
              }
            }
          }],
          "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
          "value" : "IPC.00147436.BC.PRS",
          "period" : {
            "start" : "2000-01-01"
          }
        }
      }
    }
  },
  {
    "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/RELN.126.PRS",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "RELN.126.PRS",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-role-relationships"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_RELN.126.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole RELN.126.PRS</b></p><a name=\"RELN.126.PRS\"> </a><a name=\"hcRELN.126.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-role-relationships.html\">BCRoleRelationships</a></p></div><p><b>BC Practitioner to Location Type Extension.</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system WORKSAT}\">WORKSAT</span></p><p><b>BC Owner Extension</b>: ?ngen-9?</p><p><b>period</b>: 2000-01-01 --&gt; (ongoing)</p><p><b>practitioner</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147622.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>location</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ifc.html\" title=\"Internal Facility Code\">CaBcPlrIfc</a>/IFC.00047422.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p></div>"
      },
      "extension" : [{
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-location-relationship-type-extension",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system",
            "code" : "WORKSAT"
          }]
        }
      },
      {
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
        "valueIdentifier" : {
          "assigner" : {
            "display" : "MOH"
          }
        }
      }],
      "period" : {
        "start" : "2000-01-01"
      },
      "practitioner" : {
        "identifier" : {
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
            "valueIdentifier" : {
              "assigner" : {
                "display" : "MOH"
              }
            }
          }],
          "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
          "value" : "IPC.00147622.BC.PRS",
          "period" : {
            "start" : "2000-01-01"
          }
        }
      },
      "location" : [{
        "identifier" : {
          "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
          "value" : "IFC.00047422.BC.PRS",
          "period" : {
            "start" : "2000-01-01"
          }
        }
      }]
    }
  }]
}

```
