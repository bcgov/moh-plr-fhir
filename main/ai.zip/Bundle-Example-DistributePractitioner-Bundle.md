# Example-DistributePractitioner-Bundle - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-DistributePractitioner-Bundle**

## Example Bundle: Example-DistributePractitioner-Bundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Example-DistributePractitioner-Bundle",
  "meta" : {
    "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-bundle"]
  },
  "type" : "collection",
  "entry" : [{
    "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/Practitioner/IPC.00147622.BC.PRS",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "IPC.00147622.BC.PRS",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_IPC.00147622.BC.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner IPC.00147622.BC.PRS</b></p><a name=\"IPC.00147622.BC.PRS\"> </a><a name=\"hcIPC.00147622.BC.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-practitioner.html\">BCPractitioner</a></p></div><p><b>BC Valid Period Extension</b>: 2012-12-07 --&gt; (ongoing)</p><p><b>BC Owner Extension</b>: ?ngen-9?</p><p><b>BC Birth Place Extension</b>: Ottawa ON CA </p><blockquote><p><b>BC License Status Extension</b></p><ul><li>statusCode: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-code-system SUSPENDED}\">Suspended</span></li><li>statusReasonCode: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-reason-code-system LTP}\">Left the Province</span></li><li>statusClassCode: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-class-code-system LIC}\">Licensure</span></li><li>period: 2022-06-24 --&gt; (ongoing)</li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension: ?ngen-9?</li></ul></blockquote><blockquote><p><b>BC Practitioner Disciplinary Actions Extension</b></p><ul><li>identifier: DA-1</li><li>description: Description</li><li>archiveDate: 2000-01-01</li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 1998-01-02 --&gt; (ongoing)</li><li>displayFlag: false</li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension: ?ngen-9?</li></ul></blockquote><blockquote><p><b>BC Notes Extension</b></p><ul><li>identifier: <code>http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id</code>/Note-2</li><li>text: Note text</li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 1998-01-02 --&gt; (ongoing)</li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension: ?ngen-9?</li></ul></blockquote><blockquote><p><b>BC Practitioner Conditions Extension</b></p><ul><li>identifier: <code>http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-condition-id</code>/Condition-1</li><li>restriction: false</li><li>restrictionText: Restriction text</li><li>code: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-condition-type-code-system EXP}\">EXP</span></li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 1998-01-02 --&gt; (ongoing)</li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension: ?ngen-9?</li></ul></blockquote><blockquote><p><b>BC Confidentiality Extension</b></p><ul><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 2000-01-01 --&gt; 2020-01-01</li><li>code: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-Confidentiality R}\">restricted</span></li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension: ?ngen-9?</li></ul></blockquote><blockquote><p><b>BC Practitioner to Practitioner Relationship Extension</b></p><ul><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 2022-06-30 --&gt; (ongoing)</li><li>targetPractitioner: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00763483.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</li><li>relationshipType: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system WORKSAT}\">Works at</span></li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension: ?ngen-9?</li><li>logicalId: 999999</li></ul></blockquote><p><b>identifier</b>: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147622.BC.PRS (, period: 2000-01-01 --&gt; (ongoing)), <a href=\"NamingSystem-ca-bc-plr-common-party-number.html\" title=\"Common Party Number\">CaBcPlrCommonPartyNumber</a>/CPN.00147422.BC.PRS (, period: 2000-01-01 --&gt; (ongoing)), <a href=\"NamingSystem-ca-bc-license-physician.html\" title=\"Physician ID Number\">CaBcLicensePhysician</a>/123454 (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>name</b>: GivenName FamilyName (Official)</p><p><b>telecom</b>: ph: 2503424325</p><p><b>address</b>: 19 ST ADDRESS ADDRESSLINE2TXT ADDRESS ADDRESSLINE3TXT VICTORIA BC V6P7B8 CA </p><p><b>gender</b>: Male</p><p><b>birthDate</b>: 1934-01-02</p><blockquote><p><b>qualification</b></p><blockquote><p><b>BC Practitioner Qualification Extension</b></p><ul><li>designation: Designation</li><li>equivalencyFlag: false</li><li>registrationNumber: Registration No.</li><li>issuedDate: 2000-02-03</li></ul></blockquote><p><b>BC Owner Extension</b>: ?ngen-9?</p><p><b>code</b>: <span title=\"Codes:{http://fhir.infoway-inforoute.ca/CodeSystem/scpqual BD}\">BD</span></p><p><b>period</b>: 2000-01-01 --&gt; (ongoing)</p><p><b>issuer</b>: <a href=\"#hcIPC.00147622.BC.PRS/grantingInstitution\">Organization University of Calgary</a></p></blockquote><p><b>communication</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-language-code-system B01}\">Bengali</span></p><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #grantingInstitution</b></p><a name=\"IPC.00147622.BC.PRS/grantingInstitution\"> </a><a name=\"hcIPC.00147622.BC.PRS/grantingInstitution\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-organization.html\">BCOrganization</a></p></div><p><b>name</b>: University of Calgary</p><p><b>address</b>: CALGARY AB CA </p></blockquote></div>"
      },
      "contained" : [{
        "resourceType" : "Organization",
        "id" : "grantingInstitution",
        "meta" : {
          "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization"]
        },
        "name" : "University of Calgary",
        "address" : [{
          "city" : "CALGARY",
          "state" : "AB",
          "country" : "CA"
        }]
      }],
      "extension" : [{
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
        "valuePeriod" : {
          "start" : "2012-12-07"
        }
      },
      {
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
        "valueIdentifier" : {
          "assigner" : {
            "display" : "MOH"
          }
        }
      },
      {
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-birthplace-extension",
        "valueAddress" : {
          "city" : "Ottawa",
          "state" : "ON",
          "country" : "CA"
        }
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-code-system",
              "code" : "SUSPENDED"
            }]
          }
        },
        {
          "url" : "statusReasonCode",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-reason-code-system",
              "code" : "LTP"
            }]
          }
        },
        {
          "url" : "statusClassCode",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-class-code-system",
              "code" : "LIC"
            }]
          }
        },
        {
          "url" : "period",
          "valuePeriod" : {
            "start" : "2022-06-24"
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-license-status-extension"
      },
      {
        "extension" : [{
          "url" : "identifier",
          "valueIdentifier" : {
            "value" : "DA-1"
          }
        },
        {
          "url" : "description",
          "valueString" : "Description"
        },
        {
          "url" : "archiveDate",
          "valueDateTime" : "2000-01-01"
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "1998-01-02"
          }
        },
        {
          "url" : "displayFlag",
          "valueBoolean" : false
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-disciplinary-action-extension"
      },
      {
        "extension" : [{
          "url" : "identifier",
          "valueIdentifier" : {
            "system" : "http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id",
            "value" : "Note-2"
          }
        },
        {
          "url" : "text",
          "valueString" : "Note text"
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "1998-01-02"
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-note-extension"
      },
      {
        "extension" : [{
          "url" : "identifier",
          "valueIdentifier" : {
            "system" : "http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-condition-id",
            "value" : "Condition-1"
          }
        },
        {
          "url" : "restriction",
          "valueBoolean" : false
        },
        {
          "url" : "restrictionText",
          "valueString" : "Restriction text"
        },
        {
          "url" : "code",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-condition-type-code-system",
              "code" : "EXP"
            }]
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "1998-01-02"
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-condition-extension"
      },
      {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "2000-01-01",
            "end" : "2020-01-01"
          }
        },
        {
          "url" : "code",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
              "code" : "R"
            }]
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-confidentiality-extension"
      },
      {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "2022-06-30"
          }
        },
        {
          "url" : "targetPractitioner",
          "valueReference" : {
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.00763483.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          }
        },
        {
          "url" : "relationshipType",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system",
              "code" : "WORKSAT"
            }]
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        },
        {
          "url" : "logicalId",
          "valueString" : "999999"
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-relationship-extension"
      }],
      "identifier" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        }],
        "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
        "value" : "IPC.00147622.BC.PRS",
        "period" : {
          "start" : "2000-01-01"
        }
      },
      {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        }],
        "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-common-party-number",
        "value" : "CPN.00147422.BC.PRS",
        "period" : {
          "start" : "2000-01-01"
        }
      },
      {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        }],
        "system" : "https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-license-physician",
        "value" : "123454",
        "period" : {
          "start" : "2000-01-01"
        }
      }],
      "name" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        }],
        "use" : "official",
        "family" : "FamilyName",
        "given" : ["GivenName"],
        "period" : {
          "start" : "2012-12-07"
        }
      }],
      "telecom" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
              "code" : "BC"
            }]
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        }],
        "system" : "phone",
        "value" : "2503424325",
        "period" : {
          "start" : "2000-02-02"
        }
      }],
      "address" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
              "code" : "BC"
            }]
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-address-validation-status-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-address-validation-status-code-system",
              "code" : "V"
            }]
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "PHSA"
            }
          }
        }],
        "type" : "postal",
        "line" : ["19 ST", "ADDRESS ADDRESSLINE2TXT", "ADDRESS ADDRESSLINE3TXT"],
        "city" : "VICTORIA",
        "state" : "BC",
        "postalCode" : "V6P7B8",
        "country" : "CA",
        "period" : {
          "start" : "2000-01-01"
        }
      }],
      "gender" : "male",
      "birthDate" : "1934-01-02",
      "_birthDate" : {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-birthtime-extension",
          "valueDateTime" : "1951-11-12T00:00:01-06:00"
        }]
      },
      "qualification" : [{
        "extension" : [{
          "extension" : [{
            "url" : "designation",
            "valueString" : "Designation"
          },
          {
            "url" : "equivalencyFlag",
            "valueBoolean" : false
          },
          {
            "url" : "registrationNumber",
            "valueString" : "Registration No."
          },
          {
            "url" : "issuedDate",
            "valueDateTime" : "2000-02-03"
          }],
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-qualification-extension"
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        }],
        "code" : {
          "coding" : [{
            "system" : "http://fhir.infoway-inforoute.ca/CodeSystem/scpqual",
            "code" : "BD"
          }]
        },
        "period" : {
          "start" : "2000-01-01"
        },
        "issuer" : {
          "reference" : "#grantingInstitution"
        }
      }],
      "communication" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "2000-01-01"
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        }],
        "coding" : [{
          "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-language-code-system",
          "code" : "B01"
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/IPC.00147622.BC.PRS",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "IPC.00147622.BC.PRS",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-role"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_IPC.00147622.BC.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole IPC.00147622.BC.PRS</b></p><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-practitioner-role.html\">BCPractitionerRole</a></p></div><p><b>practitioner</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147622.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>code</b>: <span title=\"Codes:{http://fhir.infoway-inforoute.ca/CodeSystem/scptype MD}\">MD</span></p><p><b>specialty</b>: <span title=\"Codes:{http://fhir.infoway-inforoute.ca/CodeSystem/scpqual AMD53}\">AMD53</span></p></div>"
      },
      "practitioner" : {
        "identifier" : {
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
            "valueIdentifier" : {
              "assigner" : {
                "display" : "MOH"
              }
            }
          }],
          "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
          "value" : "IPC.00147622.BC.PRS",
          "period" : {
            "start" : "2000-01-01"
          }
        }
      },
      "code" : [{
        "coding" : [{
          "system" : "http://fhir.infoway-inforoute.ca/CodeSystem/scptype",
          "code" : "MD"
        }]
      }],
      "specialty" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "2000-01-01",
            "end" : "2020-01-01"
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-specialty-source-extension",
          "valueString" : "Expertise source"
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        }],
        "coding" : [{
          "system" : "http://fhir.infoway-inforoute.ca/CodeSystem/scpqual",
          "code" : "AMD53"
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/RELN.153.PRS",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "RELN.153.PRS",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-role-relationships"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_RELN.153.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole RELN.153.PRS</b></p><a name=\"RELN.153.PRS\"> </a><a name=\"hcRELN.153.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-role-relationships.html\">BCRoleRelationships</a></p></div><p><b>BC Practitioner to Organization or Practitioner to Practitioner Type Extension.</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system EE}\">Employee</span></p><p><b>period</b>: 2000-01-01 --&gt; (ongoing)</p><p><b>practitioner</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147622.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>organization</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147436.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p></div>"
      },
      "extension" : [{
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-relationship-type-extension",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system",
            "code" : "EE"
          }]
        }
      }],
      "period" : {
        "start" : "2000-01-01"
      },
      "practitioner" : {
        "identifier" : {
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
            "valueIdentifier" : {
              "assigner" : {
                "display" : "MOH"
              }
            }
          }],
          "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
          "value" : "IPC.00147622.BC.PRS",
          "period" : {
            "start" : "2000-01-01"
          }
        }
      },
      "organization" : {
        "identifier" : {
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
            "valueIdentifier" : {
              "assigner" : {
                "display" : "MOH"
              }
            }
          }],
          "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
          "value" : "IPC.00147436.BC.PRS",
          "period" : {
            "start" : "2000-01-01"
          }
        }
      }
    }
  },
  {
    "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/RELN.126.PRS",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "RELN.126.PRS",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-role-relationships"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_RELN.126.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole RELN.126.PRS</b></p><a name=\"RELN.126.PRS\"> </a><a name=\"hcRELN.126.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-role-relationships.html\">BCRoleRelationships</a></p></div><p><b>BC Practitioner to Location Type Extension.</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system WORKSAT}\">WORKSAT</span></p><p><b>BC Owner Extension</b>: ?ngen-9?</p><p><b>period</b>: 2000-01-01 --&gt; (ongoing)</p><p><b>practitioner</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147622.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>location</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ifc.html\" title=\"Internal Facility Code\">CaBcPlrIfc</a>/IFC.00047422.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p></div>"
      },
      "extension" : [{
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-location-relationship-type-extension",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system",
            "code" : "WORKSAT"
          }]
        }
      },
      {
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
        "valueIdentifier" : {
          "assigner" : {
            "display" : "MOH"
          }
        }
      }],
      "period" : {
        "start" : "2000-01-01"
      },
      "practitioner" : {
        "identifier" : {
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
            "valueIdentifier" : {
              "assigner" : {
                "display" : "MOH"
              }
            }
          }],
          "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
          "value" : "IPC.00147622.BC.PRS",
          "period" : {
            "start" : "2000-01-01"
          }
        }
      },
      "location" : [{
        "identifier" : {
          "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
          "value" : "IFC.00047422.BC.PRS",
          "period" : {
            "start" : "2000-01-01"
          }
        }
      }]
    }
  }]
}

```
