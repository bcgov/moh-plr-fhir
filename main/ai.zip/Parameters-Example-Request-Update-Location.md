# Example-Request-Update-Location - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-Request-Update-Location**

## Example Parameters: Example-Request-Update-Location



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Example-Request-Update-Location",
  "parameter" : [{
    "name" : "messageId",
    "valueString" : "12344321"
  },
  {
    "name" : "messageTime",
    "valueDateTime" : "2022-06-27T01:01:01-08:00"
  },
  {
    "name" : "maintain",
    "resource" : {
      "resourceType" : "Bundle",
      "id" : "Example-UpdateLocationWithLinks-Bundle",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-location-bundle"]
      },
      "type" : "collection",
      "entry" : [{
        "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/Location/IFC.00147422.BC.PRS",
        "resource" : {
          "resourceType" : "Location",
          "id" : "IFC.00147422.BC.PRS",
          "meta" : {
            "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-location"]
          },
          "extension" : [{
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "2008-01-01"
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                  "code" : "CHG"
                }]
              }
            }],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-details-extension"
          },
          {
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-physical-address-extension",
            "valueAddress" : {
              "extension" : [{
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
                "valueCodeableConcept" : {
                  "coding" : [{
                    "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                    "code" : "FC"
                  }]
                }
              },
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
                "valueCodeableConcept" : {
                  "coding" : [{
                    "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                    "code" : "CHG"
                  }]
                }
              }],
              "type" : "physical",
              "line" : ["1000 DOUGLAS ST"],
              "city" : "VICTORIA",
              "state" : "BC",
              "postalCode" : "V6P7B8",
              "country" : "CA",
              "period" : {
                "start" : "2008-01-01"
              }
            }
          }],
          "identifier" : [{
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                  "code" : "CHG"
                }]
              }
            }],
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
            "value" : "IFC.00147422.BC.PRS",
            "period" : {
              "start" : "2008-01-01"
            }
          }],
          "name" : "General Hospital",
          "_name" : {
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "2000-01-01"
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                  "code" : "CHG"
                }]
              }
            }]
          },
          "alias" : ["Long name or alias or description"],
          "telecom" : [{
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                  "code" : "FC"
                }]
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                  "code" : "CHG"
                }]
              }
            }],
            "system" : "fax",
            "value" : "55555555551",
            "period" : {
              "start" : "1982-03-04T00:00:00-07:00"
            }
          }],
          "address" : {
            "line" : ["1000 DOUGLAS ST"],
            "city" : "LANGFORD",
            "state" : "BC",
            "country" : "CA",
            "period" : {
              "start" : "2000-01-01"
            }
          },
          "physicalType" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/location-physical-type",
              "code" : "bu"
            }]
          }
        }
      },
      {
        "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/OrganizationAffiliation/RELN.1182.PRS",
        "resource" : {
          "resourceType" : "OrganizationAffiliation",
          "id" : "RELN.1182.PRS",
          "meta" : {
            "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization-affiliation"]
          },
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                "code" : "CHG"
              }]
            }
          }],
          "period" : {
            "start" : "2000-01-01"
          },
          "organization" : {
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.70007000.PRS.BC",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          },
          "code" : [{
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system",
              "code" : "OPERATES"
            }]
          }],
          "location" : [{
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
              "value" : "IFC.00147422.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          }]
        }
      },
      {
        "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/OrganizationAffiliation/RELN.1142.PRS",
        "resource" : {
          "resourceType" : "OrganizationAffiliation",
          "id" : "RELN.1142.PRS",
          "meta" : {
            "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization-affiliation"]
          },
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                "code" : "CHG"
              }]
            }
          }],
          "period" : {
            "start" : "2000-01-01"
          },
          "organization" : {
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.90009000.PRS.BC",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          },
          "code" : [{
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system",
              "code" : "OWNS"
            }]
          }],
          "location" : [{
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
              "value" : "IFC.00147422.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          }]
        }
      },
      {
        "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/RELN.1125.PRS",
        "resource" : {
          "resourceType" : "PractitionerRole",
          "id" : "RELN.1125.PRS",
          "meta" : {
            "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-role-relationships"]
          },
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-location-relationship-type-extension",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system",
                "code" : "PRACTICES_AT"
              }]
            }
          },
          {
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                "code" : "CHG"
              }]
            }
          }],
          "period" : {
            "start" : "2000-01-01"
          },
          "practitioner" : {
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.80008000.PRS.BC",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          },
          "location" : [{
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
              "value" : "IFC.00147422.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          }]
        }
      }]
    }
  }]
}

```
