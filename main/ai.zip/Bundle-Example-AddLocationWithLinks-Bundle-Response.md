# Example-AddLocationWithLinks-Bundle-Response - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-AddLocationWithLinks-Bundle-Response**

## Example Bundle: Example-AddLocationWithLinks-Bundle-Response



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Example-AddLocationWithLinks-Bundle-Response",
  "meta" : {
    "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-location-bundle"]
  },
  "type" : "collection",
  "entry" : [{
    "fullUrl" : "urn:uuid:18734433-5c7b-42c8-ade5-22bd2c82e4f2",
    "resource" : {
      "resourceType" : "Location",
      "id" : "IFC.00147423.BC.PRS",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-location"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Location_IFC.00147423.BC.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Location IFC.00147423.BC.PRS</b></p><a name=\"IFC.00147423.BC.PRS\"> </a><a name=\"hcIFC.00147423.BC.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-location.html\">BCLocation</a></p></div><p><b>BC Facility Physical Address Extension</b>: 1000 DOUGLAS ST VICTORIA BC V6P7B8 CA </p><blockquote><p><b>BC Facility Details Extension</b></p><ul><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 2000-01-01 --&gt; (ongoing)</li></ul></blockquote><blockquote><p><b>BC Facility Health Service Area Extension</b></p><blockquote><p><b>url</b></p><a href=\"StructureDefinition-bc-facility-health-authority-extension.html\">BC Facility Health Authority Area Extension</a></blockquote><p><b>value</b>: Vancouver Island</p><blockquote><p><b>url</b></p><a href=\"StructureDefinition-bc-facility-health-service-delivery-area-extension.html\">BC Facility Health Service Delivery Area Extension</a></blockquote><p><b>value</b>: South Vancouver Island</p><blockquote><p><b>url</b></p><a href=\"StructureDefinition-bc-facility-local-health-area-extension.html\">BC Facility Local Health Area Extension</a></blockquote><p><b>value</b>: Greater Victoria</p><p><b>name</b>: Downtown Victoria/Vic West</p><p><b>code</b>: 4111</p><blockquote><p><b>url</b></p><a href=\"StructureDefinition-bc-facility-community-health-area-extension.html\">BC Facility Community Health Service Area Extension</a></blockquote><p><b>name</b>: Downtown/VicWest</p><p><b>code</b>: 40701</p><blockquote><p><b>url</b></p><a href=\"StructureDefinition-bc-facility-primary-care-network-extension.html\">BC Facility Primary Care Network Extension</a></blockquote></blockquote><p><b>identifier</b>: <a href=\"NamingSystem-ca-bc-plr-ifc.html\" title=\"Internal Facility Code\">CaBcPlrIfc</a>/IFC.00147423.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>name</b>: General Hospital</p><p><b>alias</b>: Long name or alias or description</p><p><b>telecom</b>: fax: 55555555551</p><p><b>physicalType</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/location-physical-type bu}\">Building</span></p></div>"
      },
      "extension" : [{
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-physical-address-extension",
        "valueAddress" : {
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                "code" : "FC"
              }]
            }
          }],
          "type" : "physical",
          "line" : ["1000 DOUGLAS ST"],
          "city" : "VICTORIA",
          "state" : "BC",
          "postalCode" : "V6P7B8",
          "country" : "CA",
          "period" : {
            "start" : "2000-01-01"
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "2000-01-01"
          }
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-details-extension"
      },
      {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-health-authority-extension",
          "valueString" : "Vancouver Island"
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-health-service-delivery-area-extension",
          "valueString" : "South Vancouver Island"
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-local-health-area-extension",
          "valueString" : "Greater Victoria"
        },
        {
          "extension" : [{
            "url" : "name",
            "valueString" : "Downtown Victoria/Vic West"
          },
          {
            "url" : "code",
            "valueIdentifier" : {
              "value" : "4111"
            }
          }],
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-community-health-area-extension"
        },
        {
          "extension" : [{
            "url" : "name",
            "valueString" : "Downtown/VicWest"
          },
          {
            "url" : "code",
            "valueIdentifier" : {
              "value" : "40701"
            }
          }],
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-primary-care-network-extension"
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-health-service-area-extension"
      }],
      "identifier" : [{
        "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
        "value" : "IFC.00147423.BC.PRS",
        "period" : {
          "start" : "2000-01-01"
        }
      }],
      "name" : "General Hospital",
      "_name" : {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "2000-01-01"
          }
        }]
      },
      "alias" : ["Long name or alias or description"],
      "telecom" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
              "code" : "FC"
            }]
          }
        }],
        "system" : "fax",
        "value" : "55555555551",
        "period" : {
          "start" : "1982-03-04T00:00:00-07:00"
        }
      }],
      "physicalType" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/location-physical-type",
          "code" : "bu"
        }]
      }
    }
  }]
}

```
