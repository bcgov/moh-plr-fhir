# Example-Response-Query-Practitioner-Bundle - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-Response-Query-Practitioner-Bundle**

## Example Bundle: Example-Response-Query-Practitioner-Bundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Example-Response-Query-Practitioner-Bundle",
  "type" : "searchset",
  "timestamp" : "2022-02-02T13:23:13.000-08:00",
  "total" : 1,
  "link" : [{
    "relation" : "self",
    "url" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/Practitioner/IPC32/$entityQuery"
  }],
  "entry" : [{
    "fullUrl" : "urn:uuid:7bf3d69a-482a-472e-9003-2ade5e0ccd11",
    "resource" : {
      "resourceType" : "OperationOutcome",
      "id" : "Example-OperationOutcome-7049",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-operation-outcome"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"OperationOutcome_Example-OperationOutcome-7049\"> </a><p class=\"res-header-id\"><b>Generated Narrative: OperationOutcome Example-OperationOutcome-7049</b></p><a name=\"Example-OperationOutcome-7049\"> </a><a name=\"hcExample-OperationOutcome-7049\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-operation-outcome.html\">BCOperationOutcome</a></p></div><h3>Issues</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Severity</b></td><td><b>Code</b></td><td><b>Details</b></td></tr><tr><td style=\"display: none\">*</td><td>Error</td><td>Business Rule Violation</td><td><span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-error-code-system GRS.DPS.UNK.UNK.0.0.7049}\">Some results were removed under data permission rules.</span></td></tr></table></div>"
      },
      "issue" : [{
        "severity" : "error",
        "code" : "business-rule",
        "details" : {
          "coding" : [{
            "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-error-code-system",
            "code" : "GRS.DPS.UNK.UNK.0.0.7049"
          }],
          "text" : "Some results were removed under data permission rules."
        }
      }]
    },
    "search" : {
      "mode" : "outcome"
    }
  },
  {
    "fullUrl" : "urn:uuid:11e1d315-0edf-49f0-b01c-0b42da4c97a6",
    "resource" : {
      "resourceType" : "Bundle",
      "id" : "Example-Individual-Provider-Bundle",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-bundle"]
      },
      "type" : "collection",
      "timestamp" : "2022-02-02T13:23:13.000-08:00",
      "entry" : [{
        "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/Practitioner/IPC.00147422.BC.PRS",
        "resource" : {
          "resourceType" : "Practitioner",
          "id" : "IPC.00147422.BC.PRS",
          "meta" : {
            "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner"]
          },
          "contained" : [{
            "resourceType" : "Organization",
            "id" : "grantingInstitution",
            "meta" : {
              "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization"]
            },
            "name" : "University of Calgary",
            "address" : [{
              "city" : "CALGARY",
              "state" : "AB",
              "country" : "CA"
            }]
          }],
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
            "valuePeriod" : {
              "start" : "2012-12-07"
            }
          },
          {
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-birthplace-extension",
            "valueAddress" : {
              "city" : "Ottawa",
              "state" : "ON",
              "country" : "CA"
            }
          },
          {
            "extension" : [{
              "url" : "statusCode",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-code-system",
                  "code" : "SUSPENDED"
                }]
              }
            },
            {
              "url" : "statusReasonCode",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-reason-code-system",
                  "code" : "LTP"
                }]
              }
            },
            {
              "url" : "statusClassCode",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-class-code-system",
                  "code" : "LIC"
                }]
              }
            },
            {
              "url" : "period",
              "valuePeriod" : {
                "start" : "2022-06-24"
              }
            }],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-license-status-extension"
          },
          {
            "extension" : [{
              "url" : "identifier",
              "valueIdentifier" : {
                "value" : "DA-1"
              }
            },
            {
              "url" : "description",
              "valueString" : "Description"
            },
            {
              "url" : "archiveDate",
              "valueDateTime" : "2000-01-01"
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "1998-01-02"
              }
            },
            {
              "url" : "displayFlag",
              "valueBoolean" : false
            }],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-disciplinary-action-extension"
          },
          {
            "extension" : [{
              "url" : "identifier",
              "valueIdentifier" : {
                "system" : "http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id",
                "value" : "Note-2"
              }
            },
            {
              "url" : "text",
              "valueString" : "Note text"
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "1998-01-02"
              }
            }],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-note-extension"
          },
          {
            "extension" : [{
              "url" : "identifier",
              "valueIdentifier" : {
                "system" : "http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-condition-id",
                "value" : "Condition-1"
              }
            },
            {
              "url" : "restriction",
              "valueBoolean" : false
            },
            {
              "url" : "restrictionText",
              "valueString" : "Restriction text"
            },
            {
              "url" : "code",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-condition-type-code-system",
                  "code" : "EXP"
                }]
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "1998-01-02"
              }
            }],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-condition-extension"
          },
          {
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "2000-01-01",
                "end" : "2020-01-01"
              }
            },
            {
              "url" : "code",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
                  "code" : "R"
                }]
              }
            }],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-confidentiality-extension"
          },
          {
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "2022-06-30"
              }
            },
            {
              "url" : "targetPractitioner",
              "valueReference" : {
                "identifier" : {
                  "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
                  "value" : "IPC.00763483.BC.PRS",
                  "period" : {
                    "start" : "2000-01-01"
                  }
                }
              }
            },
            {
              "url" : "relationshipType",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system",
                  "code" : "WORKSAT"
                }]
              }
            },
            {
              "url" : "logicalId",
              "valueString" : "987654"
            }],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-relationship-extension"
          }],
          "identifier" : [{
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
            "value" : "IPC.00147422.BC.PRS",
            "period" : {
              "start" : "2000-01-01"
            }
          }],
          "name" : [{
            "use" : "official",
            "family" : "FamilyName",
            "given" : ["GivenName"],
            "period" : {
              "start" : "2012-12-07"
            }
          }],
          "telecom" : [{
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                  "code" : "BC"
                }]
              }
            }],
            "system" : "phone",
            "value" : "2501112234",
            "period" : {
              "start" : "2000-02-02"
            }
          }],
          "address" : [{
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                  "code" : "BC"
                }]
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-address-validation-status-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-address-validation-status-code-system",
                  "code" : "V"
                }]
              }
            }],
            "type" : "postal",
            "line" : ["1000 DOUGLAS ST"],
            "city" : "Kelowna",
            "state" : "BC",
            "postalCode" : "V6P7B8",
            "country" : "CA",
            "period" : {
              "start" : "2000-01-01"
            }
          }],
          "gender" : "male",
          "birthDate" : "1934-01-02",
          "_birthDate" : {
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-birthtime-extension",
              "valueDateTime" : "1951-11-12T00:00:01-06:00"
            }]
          },
          "qualification" : [{
            "extension" : [{
              "extension" : [{
                "url" : "designation",
                "valueString" : "Designation"
              },
              {
                "url" : "equivalencyFlag",
                "valueBoolean" : false
              },
              {
                "url" : "registrationNumber",
                "valueString" : "Registration No."
              },
              {
                "url" : "issuedDate",
                "valueDateTime" : "2000-02-03"
              }],
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-qualification-extension"
            }],
            "code" : {
              "coding" : [{
                "system" : "http://fhir.infoway-inforoute.ca/CodeSystem/scpqual",
                "code" : "BD"
              }]
            },
            "period" : {
              "start" : "2000-01-01"
            },
            "issuer" : {
              "reference" : "#grantingInstitution"
            }
          }],
          "communication" : [{
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "2000-01-01"
              }
            }],
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-language-code-system",
              "code" : "B01"
            }]
          }]
        }
      },
      {
        "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/IPC.00147422.BC.PRS",
        "resource" : {
          "resourceType" : "PractitionerRole",
          "id" : "IPC.00147422.BC.PRS",
          "meta" : {
            "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-role"]
          },
          "practitioner" : {
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.00147422.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          },
          "code" : [{
            "coding" : [{
              "system" : "http://fhir.infoway-inforoute.ca/CodeSystem/scptype",
              "code" : "MD"
            }]
          }],
          "specialty" : [{
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "2000-01-01",
                "end" : "2020-01-01"
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-specialty-source-extension",
              "valueString" : "Expertise source"
            }],
            "coding" : [{
              "system" : "http://fhir.infoway-inforoute.ca/CodeSystem/scpqual",
              "code" : "AMD53"
            }]
          }]
        }
      },
      {
        "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/RELN.123.PRS",
        "resource" : {
          "resourceType" : "PractitionerRole",
          "id" : "RELN.123.PRS",
          "meta" : {
            "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-role-relationships"]
          },
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-relationship-type-extension",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system",
                "code" : "EE"
              }]
            }
          }],
          "period" : {
            "start" : "2000-01-01"
          },
          "practitioner" : {
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.00147422.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          },
          "organization" : {
            "identifier" : {
              "extension" : [{
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
                "valueIdentifier" : {
                  "assigner" : {
                    "display" : "MOH"
                  }
                }
              }],
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.00147436.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          }
        }
      },
      {
        "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/RELN.125.PRS",
        "resource" : {
          "resourceType" : "PractitionerRole",
          "id" : "RELN.125.PRS",
          "meta" : {
            "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-role-relationships"]
          },
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-location-relationship-type-extension",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system",
                "code" : "WORKSAT"
              }]
            }
          }],
          "period" : {
            "start" : "2000-01-01"
          },
          "practitioner" : {
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.00147422.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          },
          "location" : [{
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
              "value" : "IFC.00047422.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          }]
        }
      }]
    },
    "search" : {
      "mode" : "match"
    }
  }]
}

```
