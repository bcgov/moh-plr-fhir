# Example-Request-Update-Organization - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-Request-Update-Organization**

## Example Parameters: Example-Request-Update-Organization



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Example-Request-Update-Organization",
  "parameter" : [{
    "name" : "messageId",
    "valueString" : "12344321"
  },
  {
    "name" : "messageTime",
    "valueDateTime" : "2022-06-27T01:01:01-08:00"
  },
  {
    "name" : "maintain",
    "resource" : {
      "resourceType" : "Bundle",
      "id" : "Example-UpdateOrganization-Bundle",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization-bundle"]
      },
      "type" : "collection",
      "entry" : [{
        "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/Organization/IPC.00147434.BC.PRS",
        "resource" : {
          "resourceType" : "Organization",
          "id" : "IPC.00147434.BC.PRS",
          "meta" : {
            "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization"]
          },
          "extension" : [{
            "extension" : [{
              "url" : "identifier",
              "valueIdentifier" : {
                "system" : "http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id",
                "value" : "Note-3"
              }
            },
            {
              "url" : "text",
              "valueString" : "Note text"
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "1998-01-02"
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                  "code" : "CHG"
                }]
              }
            }],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-note-extension"
          }],
          "identifier" : [{
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-org-id",
            "value" : "123123123",
            "period" : {
              "start" : "2000-01-01"
            }
          },
          {
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
              "valueIdentifier" : {
                "assigner" : {
                  "display" : "MOH"
                }
              }
            }],
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
            "value" : "IPC.00147434.BC.PRS",
            "period" : {
              "start" : "2000-01-01"
            }
          }],
          "active" : true,
          "type" : [{
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-organization-role-code-system",
              "code" : "ORG"
            }]
          }],
          "name" : "Kelowna Clinic",
          "_name" : {
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-name-use-extension",
              "valueCode" : "official"
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "2014-01-31T00:00:00-07:00"
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                  "code" : "CHG"
                }]
              }
            }]
          },
          "alias" : ["ABC Clinic - Kelowna"],
          "telecom" : [{
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                  "code" : "BC"
                }]
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                  "code" : "CHG"
                }]
              }
            }],
            "system" : "phone",
            "value" : "2502222234",
            "period" : {
              "start" : "2000-02-02"
            }
          }],
          "address" : [{
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                  "code" : "BC"
                }]
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                  "code" : "CHG"
                }]
              }
            }],
            "type" : "postal",
            "line" : ["1000 DOUGLAS ST"],
            "city" : "VICTORIA",
            "state" : "BC",
            "postalCode" : "V6P7B8",
            "country" : "CA",
            "period" : {
              "start" : "2000-01-01"
            }
          }]
        }
      },
      {
        "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/OrganizationAffiliation/RELN.182.PRS",
        "resource" : {
          "resourceType" : "OrganizationAffiliation",
          "id" : "RELN.182.PRS",
          "meta" : {
            "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization-affiliation"]
          },
          "period" : {
            "start" : "2000-01-01"
          },
          "organization" : {
            "identifier" : {
              "extension" : [{
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
                "valueIdentifier" : {
                  "assigner" : {
                    "display" : "MOH"
                  }
                }
              }],
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.00147434.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          },
          "code" : [{
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system",
              "code" : "operatesfrom"
            }]
          }],
          "location" : [{
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
              "value" : "IFC.00047422.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          }]
        }
      },
      {
        "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/OrganizationAffiliation/RELN.181.PRS",
        "resource" : {
          "resourceType" : "OrganizationAffiliation",
          "id" : "RELN.181.PRS",
          "meta" : {
            "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization-affiliation"]
          },
          "period" : {
            "start" : "2000-01-01"
          },
          "organization" : {
            "identifier" : {
              "extension" : [{
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
                "valueIdentifier" : {
                  "assigner" : {
                    "display" : "MOH"
                  }
                }
              }],
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.00147434.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          },
          "participatingOrganization" : {
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.001164553.BC.PRS",
              "period" : {
                "start" : "2000-02-02"
              }
            }
          },
          "code" : [{
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system",
              "code" : "deptof"
            }]
          }]
        }
      },
      {
        "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/RELN.193.PRS",
        "resource" : {
          "resourceType" : "PractitionerRole",
          "id" : "RELN.193.PRS",
          "meta" : {
            "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-role-relationships"]
          },
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-relationship-type-extension",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system",
                "code" : "EE"
              }]
            }
          }],
          "period" : {
            "start" : "2000-01-01"
          },
          "practitioner" : {
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.00147434.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          },
          "organization" : {
            "identifier" : {
              "extension" : [{
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
                "valueIdentifier" : {
                  "assigner" : {
                    "display" : "MOH"
                  }
                }
              }],
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.00147434.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          }
        }
      }]
    }
  }]
}

```
