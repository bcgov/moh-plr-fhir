# Example-UpdateOrganization-Bundle-Response - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-UpdateOrganization-Bundle-Response**

## Example Bundle: Example-UpdateOrganization-Bundle-Response



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Example-UpdateOrganization-Bundle-Response",
  "meta" : {
    "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization-bundle"]
  },
  "type" : "collection",
  "entry" : [{
    "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/Organization/IPC.00147436.BC.PRS",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "IPC.00147436.BC.PRS",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_IPC.00147436.BC.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization IPC.00147436.BC.PRS</b></p><a name=\"IPC.00147436.BC.PRS\"> </a><a name=\"hcIPC.00147436.BC.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-organization.html\">BCOrganization</a></p></div><blockquote><p><b>BC Notes Extension</b></p><ul><li>identifier: <code>http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id</code>/Note-2</li><li>text: Note text</li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 1998-01-02 --&gt; (ongoing)</li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension: ?ngen-9?</li></ul></blockquote><p><b>identifier</b>: <a href=\"NamingSystem-ca-bc-plr-org-id.html\" title=\"Organization\">CaBcPlrOrgId</a>/123123123 (, period: 2000-01-01 --&gt; (ongoing)), <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147436.BC.PRS (, period: 2000-01-01 --&gt; (ongoing)), <a href=\"NamingSystem-ca-bc-plr-common-party-number.html\" title=\"Common Party Number\">CaBcPlrCommonPartyNumber</a>/CPN.00147433.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-organization-role-code-system CLINIC}\">Clinic</span></p><p><b>name</b>: Kelowna Clinic</p><p><b>alias</b>: ABC Clinic - Kelowna</p><p><b>telecom</b>: ph: 2503424343</p><p><b>address</b>: 19 ST ADDRESS ADDRESSLINE2TXT ADDRESS ADDRESSLINE3TXT VICTORIA BC V6P7B8 CA </p></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "identifier",
          "valueIdentifier" : {
            "system" : "http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id",
            "value" : "Note-2"
          }
        },
        {
          "url" : "text",
          "valueString" : "Note text"
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "1998-01-02"
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "PHSA"
            }
          }
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-note-extension"
      }],
      "identifier" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "PHSA"
            }
          }
        }],
        "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-org-id",
        "value" : "123123123",
        "period" : {
          "start" : "2000-01-01"
        }
      },
      {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "MOH"
            }
          }
        }],
        "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
        "value" : "IPC.00147436.BC.PRS",
        "period" : {
          "start" : "2000-01-01"
        }
      },
      {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "PHSA"
            }
          }
        }],
        "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-common-party-number",
        "value" : "CPN.00147433.BC.PRS",
        "period" : {
          "start" : "2000-01-01"
        }
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-organization-role-code-system",
          "code" : "CLINIC"
        }]
      }],
      "name" : "Kelowna Clinic",
      "_name" : {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-name-use-extension",
          "valueCode" : "official"
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "2014-01-31T00:00:00-07:00"
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "PHSA"
            }
          }
        }]
      },
      "alias" : ["ABC Clinic - Kelowna"],
      "telecom" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
              "code" : "BC"
            }]
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "PHSA"
            }
          }
        }],
        "system" : "phone",
        "value" : "2503424343",
        "period" : {
          "start" : "2000-02-02"
        }
      }],
      "address" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
              "code" : "BC"
            }]
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-address-validation-status-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-address-validation-status-code-system",
              "code" : "V"
            }]
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
          "valueIdentifier" : {
            "assigner" : {
              "display" : "PHSA"
            }
          }
        }],
        "type" : "postal",
        "line" : ["19 ST", "ADDRESS ADDRESSLINE2TXT", "ADDRESS ADDRESSLINE3TXT"],
        "city" : "VICTORIA",
        "state" : "BC",
        "postalCode" : "V6P7B8",
        "country" : "CA",
        "period" : {
          "start" : "2000-01-01"
        }
      }]
    }
  }]
}

```
