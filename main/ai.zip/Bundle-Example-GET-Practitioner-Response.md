# Example-GET-Practitioner-Response - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-GET-Practitioner-Response**

## Example Bundle: Example-GET-Practitioner-Response



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Example-GET-Practitioner-Response",
  "type" : "searchset",
  "link" : [{
    "relation" : "self",
    "url" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/Practitioner/IPC.00047422.BC.PRS"
  }],
  "entry" : [{
    "fullUrl" : "urn:uuid:3abd58f7-f226-4358-bdfd-2bb64bc93552",
    "resource" : {
      "resourceType" : "OperationOutcome",
      "id" : "Example-OperationOutcome-Success",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-operation-outcome"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"OperationOutcome_Example-OperationOutcome-Success\"> </a><p class=\"res-header-id\"><b>Generated Narrative: OperationOutcome Example-OperationOutcome-Success</b></p><a name=\"Example-OperationOutcome-Success\"> </a><a name=\"hcExample-OperationOutcome-Success\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-operation-outcome.html\">BCOperationOutcome</a></p></div><h3>Issues</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Severity</b></td><td><b>Code</b></td><td><b>Details</b></td></tr><tr><td style=\"display: none\">*</td><td>Information</td><td>Business Rule Violation</td><td><span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-error-code-system PRS.PRP.MTN.UNK.0.0.7067}\">Query successful</span></td></tr></table></div>"
      },
      "issue" : [{
        "severity" : "information",
        "code" : "business-rule",
        "details" : {
          "coding" : [{
            "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-error-code-system",
            "code" : "PRS.PRP.MTN.UNK.0.0.7067"
          }],
          "text" : "Query successful"
        }
      }]
    },
    "search" : {
      "mode" : "outcome"
    }
  },
  {
    "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/Practitioner/IPC.00047422.BC.PRS",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "IPC.00047422.BC.PRS",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_IPC.00047422.BC.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner IPC.00047422.BC.PRS</b></p><a name=\"IPC.00047422.BC.PRS\"> </a><a name=\"hcIPC.00047422.BC.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-practitioner.html\">BCPractitioner</a></p></div><p><b>BC Valid Period Extension</b>: 2012-12-07 --&gt; (ongoing)</p><p><b>BC Birth Place Extension</b>: Ottawa ON CA </p><blockquote><p><b>BC License Status Extension</b></p><ul><li>statusCode: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-code-system SUSPENDED}\">Suspended</span></li><li>statusReasonCode: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-reason-code-system LTP}\">Left the Province</span></li><li>statusClassCode: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-class-code-system LIC}\">Licensure</span></li><li>period: 2022-06-24 --&gt; (ongoing)</li></ul></blockquote><blockquote><p><b>BC Practitioner Disciplinary Actions Extension</b></p><ul><li>identifier: DA-1</li><li>description: Description</li><li>archiveDate: 2000-01-01</li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 1998-01-02 --&gt; (ongoing)</li><li>displayFlag: false</li></ul></blockquote><blockquote><p><b>BC Notes Extension</b></p><ul><li>identifier: <code>http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id</code>/Note-2</li><li>text: Note text</li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 1998-01-02 --&gt; (ongoing)</li></ul></blockquote><blockquote><p><b>BC Practitioner Conditions Extension</b></p><ul><li>identifier: <code>http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-condition-id</code>/Condition-1</li><li>restriction: false</li><li>restrictionText: Restriction text</li><li>code: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-condition-type-code-system EXP}\">EXP</span></li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 1998-01-02 --&gt; (ongoing)</li></ul></blockquote><blockquote><p><b>BC Confidentiality Extension</b></p><ul><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 2000-01-01 --&gt; 2020-01-01</li><li>code: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-Confidentiality R}\">restricted</span></li></ul></blockquote><blockquote><p><b>BC Practitioner to Practitioner Relationship Extension</b></p><ul><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 2022-06-30 --&gt; (ongoing)</li><li>targetPractitioner: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00763483.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</li><li>relationshipType: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system WORKSAT}\">Works at</span></li><li>logicalId: 987654</li></ul></blockquote><p><b>identifier</b>: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00047422.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>name</b>: GivenName FamilyName (Official)</p><p><b>telecom</b>: ph: 2501112234</p><p><b>address</b>: 1000 DOUGLAS ST Kelowna BC V6P7B8 CA </p><p><b>gender</b>: Male</p><p><b>birthDate</b>: 1934-01-02</p><h3>Qualifications</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Extension</b></td><td><b>Code</b></td><td><b>Period</b></td><td><b>Issuer</b></td></tr><tr><td style=\"display: none\">*</td><td/><td><span title=\"Codes:{http://fhir.infoway-inforoute.ca/CodeSystem/scpqual BD}\">BD</span></td><td>2000-01-01 --&gt; (ongoing)</td><td><a href=\"#hcIPC.00047422.BC.PRS/grantingInstitution\">Organization University of Calgary</a></td></tr></table><p><b>communication</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-language-code-system B01}\">Bengali</span>, <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-language-code-system F16}\">French</span></p><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Organization #grantingInstitution</b></p><a name=\"IPC.00047422.BC.PRS/grantingInstitution\"> </a><a name=\"hcIPC.00047422.BC.PRS/grantingInstitution\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-organization.html\">BCOrganization</a></p></div><p><b>name</b>: University of Calgary</p><p><b>address</b>: CALGARY AB CA </p></blockquote></div>"
      },
      "contained" : [{
        "resourceType" : "Organization",
        "id" : "grantingInstitution",
        "meta" : {
          "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization"]
        },
        "name" : "University of Calgary",
        "address" : [{
          "city" : "CALGARY",
          "state" : "AB",
          "country" : "CA"
        }]
      }],
      "extension" : [{
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
        "valuePeriod" : {
          "start" : "2012-12-07"
        }
      },
      {
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-birthplace-extension",
        "valueAddress" : {
          "city" : "Ottawa",
          "state" : "ON",
          "country" : "CA"
        }
      },
      {
        "extension" : [{
          "url" : "statusCode",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-code-system",
              "code" : "SUSPENDED"
            }]
          }
        },
        {
          "url" : "statusReasonCode",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-reason-code-system",
              "code" : "LTP"
            }]
          }
        },
        {
          "url" : "statusClassCode",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-class-code-system",
              "code" : "LIC"
            }]
          }
        },
        {
          "url" : "period",
          "valuePeriod" : {
            "start" : "2022-06-24"
          }
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-license-status-extension"
      },
      {
        "extension" : [{
          "url" : "identifier",
          "valueIdentifier" : {
            "value" : "DA-1"
          }
        },
        {
          "url" : "description",
          "valueString" : "Description"
        },
        {
          "url" : "archiveDate",
          "valueDateTime" : "2000-01-01"
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "1998-01-02"
          }
        },
        {
          "url" : "displayFlag",
          "valueBoolean" : false
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-disciplinary-action-extension"
      },
      {
        "extension" : [{
          "url" : "identifier",
          "valueIdentifier" : {
            "system" : "http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id",
            "value" : "Note-2"
          }
        },
        {
          "url" : "text",
          "valueString" : "Note text"
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "1998-01-02"
          }
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-note-extension"
      },
      {
        "extension" : [{
          "url" : "identifier",
          "valueIdentifier" : {
            "system" : "http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-condition-id",
            "value" : "Condition-1"
          }
        },
        {
          "url" : "restriction",
          "valueBoolean" : false
        },
        {
          "url" : "restrictionText",
          "valueString" : "Restriction text"
        },
        {
          "url" : "code",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-condition-type-code-system",
              "code" : "EXP"
            }]
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "1998-01-02"
          }
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-condition-extension"
      },
      {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "2000-01-01",
            "end" : "2020-01-01"
          }
        },
        {
          "url" : "code",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
              "code" : "R"
            }]
          }
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-confidentiality-extension"
      },
      {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "2022-06-30"
          }
        },
        {
          "url" : "targetPractitioner",
          "valueReference" : {
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.00763483.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          }
        },
        {
          "url" : "relationshipType",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system",
              "code" : "WORKSAT"
            }]
          }
        },
        {
          "url" : "logicalId",
          "valueString" : "987654"
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-relationship-extension"
      }],
      "identifier" : [{
        "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
        "value" : "IPC.00047422.BC.PRS",
        "period" : {
          "start" : "2000-01-01"
        }
      }],
      "name" : [{
        "use" : "official",
        "family" : "FamilyName",
        "given" : ["GivenName"],
        "period" : {
          "start" : "2012-12-07"
        }
      }],
      "telecom" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
              "code" : "BC"
            }]
          }
        }],
        "system" : "phone",
        "value" : "2501112234",
        "period" : {
          "start" : "2000-02-02"
        }
      }],
      "address" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
              "code" : "BC"
            }]
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-address-validation-status-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-address-validation-status-code-system",
              "code" : "V"
            }]
          }
        }],
        "type" : "postal",
        "line" : ["1000 DOUGLAS ST"],
        "city" : "Kelowna",
        "state" : "BC",
        "postalCode" : "V6P7B8",
        "country" : "CA",
        "period" : {
          "start" : "2000-01-01"
        }
      }],
      "gender" : "male",
      "birthDate" : "1934-01-02",
      "_birthDate" : {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-birthtime-extension",
          "valueDateTime" : "1951-11-12T00:00:01-06:00"
        }]
      },
      "qualification" : [{
        "extension" : [{
          "extension" : [{
            "url" : "designation",
            "valueString" : "Designation"
          },
          {
            "url" : "equivalencyFlag",
            "valueBoolean" : false
          },
          {
            "url" : "registrationNumber",
            "valueString" : "Registration No."
          },
          {
            "url" : "issuedDate",
            "valueDateTime" : "2000-02-03"
          }],
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-qualification-extension"
        }],
        "code" : {
          "coding" : [{
            "system" : "http://fhir.infoway-inforoute.ca/CodeSystem/scpqual",
            "code" : "BD"
          }]
        },
        "period" : {
          "start" : "2000-01-01"
        },
        "issuer" : {
          "reference" : "#grantingInstitution"
        }
      }],
      "communication" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "2000-01-01"
          }
        }],
        "coding" : [{
          "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-language-code-system",
          "code" : "B01"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "2000-01-01"
          }
        }],
        "coding" : [{
          "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-language-code-system",
          "code" : "F16"
        }]
      }]
    },
    "search" : {
      "mode" : "match"
    }
  }]
}

```
