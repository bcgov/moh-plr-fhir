# Example-UpdateLocationWithLinks-Bundle - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-UpdateLocationWithLinks-Bundle**

## Example Bundle: Example-UpdateLocationWithLinks-Bundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Example-UpdateLocationWithLinks-Bundle",
  "meta" : {
    "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-location-bundle"]
  },
  "type" : "collection",
  "entry" : [{
    "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/Location/IFC.00147422.BC.PRS",
    "resource" : {
      "resourceType" : "Location",
      "id" : "IFC.00147422.BC.PRS",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-location"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Location_IFC.00147422.BC.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Location IFC.00147422.BC.PRS</b></p><a name=\"IFC.00147422.BC.PRS\"> </a><a name=\"hcIFC.00147422.BC.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-location.html\">BCLocation</a></p></div><blockquote><p><b>BC Facility Details Extension</b></p><ul><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 2008-01-01 --&gt; (ongoing)</li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system CHG}\">Change</span></li></ul></blockquote><p><b>BC Facility Physical Address Extension</b>: 1000 DOUGLAS ST VICTORIA BC V6P7B8 CA </p><p><b>identifier</b>: <a href=\"NamingSystem-ca-bc-plr-ifc.html\" title=\"Internal Facility Code\">CaBcPlrIfc</a>/IFC.00147422.BC.PRS (, period: 2008-01-01 --&gt; (ongoing))</p><p><b>name</b>: General Hospital</p><p><b>alias</b>: Long name or alias or description</p><p><b>telecom</b>: fax: 55555555551</p><p><b>address</b>: 1000 DOUGLAS ST LANGFORD BC CA </p><p><b>physicalType</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/location-physical-type bu}\">Building</span></p></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "2008-01-01"
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
              "code" : "CHG"
            }]
          }
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-details-extension"
      },
      {
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-physical-address-extension",
        "valueAddress" : {
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                "code" : "FC"
              }]
            }
          },
          {
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                "code" : "CHG"
              }]
            }
          }],
          "type" : "physical",
          "line" : ["1000 DOUGLAS ST"],
          "city" : "VICTORIA",
          "state" : "BC",
          "postalCode" : "V6P7B8",
          "country" : "CA",
          "period" : {
            "start" : "2008-01-01"
          }
        }
      }],
      "identifier" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
              "code" : "CHG"
            }]
          }
        }],
        "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
        "value" : "IFC.00147422.BC.PRS",
        "period" : {
          "start" : "2008-01-01"
        }
      }],
      "name" : "General Hospital",
      "_name" : {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "2000-01-01"
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
              "code" : "CHG"
            }]
          }
        }]
      },
      "alias" : ["Long name or alias or description"],
      "telecom" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
              "code" : "FC"
            }]
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
              "code" : "CHG"
            }]
          }
        }],
        "system" : "fax",
        "value" : "55555555551",
        "period" : {
          "start" : "1982-03-04T00:00:00-07:00"
        }
      }],
      "address" : {
        "line" : ["1000 DOUGLAS ST"],
        "city" : "LANGFORD",
        "state" : "BC",
        "country" : "CA",
        "period" : {
          "start" : "2000-01-01"
        }
      },
      "physicalType" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/location-physical-type",
          "code" : "bu"
        }]
      }
    }
  },
  {
    "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/OrganizationAffiliation/RELN.1182.PRS",
    "resource" : {
      "resourceType" : "OrganizationAffiliation",
      "id" : "RELN.1182.PRS",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization-affiliation"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"OrganizationAffiliation_RELN.1182.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: OrganizationAffiliation RELN.1182.PRS</b></p><a name=\"RELN.1182.PRS\"> </a><a name=\"hcRELN.1182.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-organization-affiliation.html\">BCOrganizationAffiliation</a></p></div><p><b>BC End Reason Extension</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system CHG}\">Change</span></p><p><b>period</b>: 2000-01-01 --&gt; (ongoing)</p><p><b>organization</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.70007000.PRS.BC (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>code</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system OPERATES}\">OPERATES</span></p><p><b>location</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ifc.html\" title=\"Internal Facility Code\">CaBcPlrIfc</a>/IFC.00147422.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p></div>"
      },
      "extension" : [{
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
            "code" : "CHG"
          }]
        }
      }],
      "period" : {
        "start" : "2000-01-01"
      },
      "organization" : {
        "identifier" : {
          "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
          "value" : "IPC.70007000.PRS.BC",
          "period" : {
            "start" : "2000-01-01"
          }
        }
      },
      "code" : [{
        "coding" : [{
          "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system",
          "code" : "OPERATES"
        }]
      }],
      "location" : [{
        "identifier" : {
          "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
          "value" : "IFC.00147422.BC.PRS",
          "period" : {
            "start" : "2000-01-01"
          }
        }
      }]
    }
  },
  {
    "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/OrganizationAffiliation/RELN.1142.PRS",
    "resource" : {
      "resourceType" : "OrganizationAffiliation",
      "id" : "RELN.1142.PRS",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization-affiliation"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"OrganizationAffiliation_RELN.1142.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: OrganizationAffiliation RELN.1142.PRS</b></p><a name=\"RELN.1142.PRS\"> </a><a name=\"hcRELN.1142.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-organization-affiliation.html\">BCOrganizationAffiliation</a></p></div><p><b>BC End Reason Extension</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system CHG}\">Change</span></p><p><b>period</b>: 2000-01-01 --&gt; (ongoing)</p><p><b>organization</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.90009000.PRS.BC (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>code</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system OWNS}\">OWNS</span></p><p><b>location</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ifc.html\" title=\"Internal Facility Code\">CaBcPlrIfc</a>/IFC.00147422.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p></div>"
      },
      "extension" : [{
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
            "code" : "CHG"
          }]
        }
      }],
      "period" : {
        "start" : "2000-01-01"
      },
      "organization" : {
        "identifier" : {
          "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
          "value" : "IPC.90009000.PRS.BC",
          "period" : {
            "start" : "2000-01-01"
          }
        }
      },
      "code" : [{
        "coding" : [{
          "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system",
          "code" : "OWNS"
        }]
      }],
      "location" : [{
        "identifier" : {
          "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
          "value" : "IFC.00147422.BC.PRS",
          "period" : {
            "start" : "2000-01-01"
          }
        }
      }]
    }
  },
  {
    "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/RELN.1125.PRS",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "RELN.1125.PRS",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-role-relationships"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_RELN.1125.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole RELN.1125.PRS</b></p><a name=\"RELN.1125.PRS\"> </a><a name=\"hcRELN.1125.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-role-relationships.html\">BCRoleRelationships</a></p></div><p><b>BC Practitioner to Location Type Extension.</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system PRACTICES_AT}\">PRACTICES_AT</span></p><p><b>BC End Reason Extension</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system CHG}\">Change</span></p><p><b>period</b>: 2000-01-01 --&gt; (ongoing)</p><p><b>practitioner</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.80008000.PRS.BC (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>location</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ifc.html\" title=\"Internal Facility Code\">CaBcPlrIfc</a>/IFC.00147422.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p></div>"
      },
      "extension" : [{
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-location-relationship-type-extension",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system",
            "code" : "PRACTICES_AT"
          }]
        }
      },
      {
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
            "code" : "CHG"
          }]
        }
      }],
      "period" : {
        "start" : "2000-01-01"
      },
      "practitioner" : {
        "identifier" : {
          "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
          "value" : "IPC.80008000.PRS.BC",
          "period" : {
            "start" : "2000-01-01"
          }
        }
      },
      "location" : [{
        "identifier" : {
          "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
          "value" : "IFC.00147422.BC.PRS",
          "period" : {
            "start" : "2000-01-01"
          }
        }
      }]
    }
  }]
}

```
