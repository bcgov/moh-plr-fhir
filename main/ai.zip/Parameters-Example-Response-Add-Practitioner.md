# Example-Response-Add-Practitioner - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-Response-Add-Practitioner**

## Example Parameters: Example-Response-Add-Practitioner



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Example-Response-Add-Practitioner",
  "parameter" : [{
    "name" : "messageId",
    "valueString" : "98766789"
  },
  {
    "name" : "messageTime",
    "valueDateTime" : "2022-06-27T01:01:03-08:00"
  },
  {
    "name" : "requestMessageId",
    "valueString" : "12344321"
  },
  {
    "name" : "maintain",
    "resource" : {
      "resourceType" : "Bundle",
      "id" : "Example-AddPractitioner-Bundle-Response",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-bundle"]
      },
      "type" : "collection",
      "entry" : [{
        "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/Practitioner/IPC.00147622.BC.PRS",
        "resource" : {
          "resourceType" : "Practitioner",
          "id" : "IPC.00147622.BC.PRS",
          "meta" : {
            "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner"]
          },
          "contained" : [{
            "resourceType" : "Organization",
            "id" : "grantingInstitution",
            "meta" : {
              "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization"]
            },
            "name" : "University of Calgary",
            "address" : [{
              "city" : "CALGARY",
              "state" : "AB",
              "country" : "CA"
            }]
          }],
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
            "valuePeriod" : {
              "start" : "2012-12-07"
            }
          },
          {
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
            "valueIdentifier" : {
              "assigner" : {
                "display" : "MOH"
              }
            }
          },
          {
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-birthplace-extension",
            "valueAddress" : {
              "city" : "Ottawa",
              "state" : "ON",
              "country" : "CA"
            }
          },
          {
            "extension" : [{
              "url" : "statusCode",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-code-system",
                  "code" : "SUSPENDED"
                }]
              }
            },
            {
              "url" : "statusReasonCode",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-reason-code-system",
                  "code" : "LTP"
                }]
              }
            },
            {
              "url" : "statusClassCode",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-class-code-system",
                  "code" : "LIC"
                }]
              }
            },
            {
              "url" : "period",
              "valuePeriod" : {
                "start" : "2022-06-24"
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
              "valueIdentifier" : {
                "assigner" : {
                  "display" : "MOH"
                }
              }
            }],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-license-status-extension"
          },
          {
            "extension" : [{
              "url" : "identifier",
              "valueIdentifier" : {
                "value" : "DA-1"
              }
            },
            {
              "url" : "description",
              "valueString" : "Description"
            },
            {
              "url" : "archiveDate",
              "valueDateTime" : "2000-01-01"
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "1998-01-02"
              }
            },
            {
              "url" : "displayFlag",
              "valueBoolean" : false
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
              "valueIdentifier" : {
                "assigner" : {
                  "display" : "MOH"
                }
              }
            }],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-disciplinary-action-extension"
          },
          {
            "extension" : [{
              "url" : "identifier",
              "valueIdentifier" : {
                "system" : "http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id",
                "value" : "Note-2"
              }
            },
            {
              "url" : "text",
              "valueString" : "Note text"
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "1998-01-02"
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
              "valueIdentifier" : {
                "assigner" : {
                  "display" : "MOH"
                }
              }
            }],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-note-extension"
          },
          {
            "extension" : [{
              "url" : "identifier",
              "valueIdentifier" : {
                "system" : "http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-condition-id",
                "value" : "Condition-1"
              }
            },
            {
              "url" : "restriction",
              "valueBoolean" : false
            },
            {
              "url" : "restrictionText",
              "valueString" : "Restriction text"
            },
            {
              "url" : "code",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-condition-type-code-system",
                  "code" : "EXP"
                }]
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "1998-01-02"
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
              "valueIdentifier" : {
                "assigner" : {
                  "display" : "MOH"
                }
              }
            }],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-condition-extension"
          },
          {
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "2000-01-01",
                "end" : "2020-01-01"
              }
            },
            {
              "url" : "code",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
                  "code" : "R"
                }]
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
              "valueIdentifier" : {
                "assigner" : {
                  "display" : "MOH"
                }
              }
            }],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-confidentiality-extension"
          },
          {
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "2022-06-30"
              }
            },
            {
              "url" : "targetPractitioner",
              "valueReference" : {
                "identifier" : {
                  "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
                  "value" : "IPC.00763483.BC.PRS",
                  "period" : {
                    "start" : "2000-01-01"
                  }
                }
              }
            },
            {
              "url" : "relationshipType",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system",
                  "code" : "WORKSAT"
                }]
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
              "valueIdentifier" : {
                "assigner" : {
                  "display" : "MOH"
                }
              }
            },
            {
              "url" : "logicalId",
              "valueString" : "999999"
            }],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-relationship-extension"
          }],
          "identifier" : [{
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
              "valueIdentifier" : {
                "assigner" : {
                  "display" : "MOH"
                }
              }
            }],
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
            "value" : "IPC.00147622.BC.PRS",
            "period" : {
              "start" : "2000-01-01"
            }
          },
          {
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
              "valueIdentifier" : {
                "assigner" : {
                  "display" : "MOH"
                }
              }
            }],
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-common-party-number",
            "value" : "CPN.00147422.BC.PRS",
            "period" : {
              "start" : "2000-01-01"
            }
          },
          {
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
              "valueIdentifier" : {
                "assigner" : {
                  "display" : "MOH"
                }
              }
            }],
            "system" : "https://fhir.infoway-inforoute.ca/NamingSystem/ca-bc-license-physician",
            "value" : "123454",
            "period" : {
              "start" : "2000-01-01"
            }
          }],
          "name" : [{
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
              "valueIdentifier" : {
                "assigner" : {
                  "display" : "MOH"
                }
              }
            }],
            "use" : "official",
            "family" : "FamilyName",
            "given" : ["GivenName"],
            "period" : {
              "start" : "2012-12-07"
            }
          }],
          "telecom" : [{
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                  "code" : "BC"
                }]
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
              "valueIdentifier" : {
                "assigner" : {
                  "display" : "MOH"
                }
              }
            }],
            "system" : "phone",
            "value" : "2503424325",
            "period" : {
              "start" : "2000-02-02"
            }
          }],
          "address" : [{
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                  "code" : "BC"
                }]
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-address-validation-status-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-address-validation-status-code-system",
                  "code" : "V"
                }]
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
              "valueIdentifier" : {
                "assigner" : {
                  "display" : "PHSA"
                }
              }
            }],
            "type" : "postal",
            "line" : ["19 ST", "ADDRESS ADDRESSLINE2TXT", "ADDRESS ADDRESSLINE3TXT"],
            "city" : "VICTORIA",
            "state" : "BC",
            "postalCode" : "V6P7B8",
            "country" : "CA",
            "period" : {
              "start" : "2000-01-01"
            }
          }],
          "gender" : "male",
          "birthDate" : "1934-01-02",
          "_birthDate" : {
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-birthtime-extension",
              "valueDateTime" : "1951-11-12T00:00:01-06:00"
            }]
          },
          "qualification" : [{
            "extension" : [{
              "extension" : [{
                "url" : "designation",
                "valueString" : "Designation"
              },
              {
                "url" : "equivalencyFlag",
                "valueBoolean" : false
              },
              {
                "url" : "registrationNumber",
                "valueString" : "Registration No."
              },
              {
                "url" : "issuedDate",
                "valueDateTime" : "2000-02-03"
              }],
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-qualification-extension"
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
              "valueIdentifier" : {
                "assigner" : {
                  "display" : "MOH"
                }
              }
            }],
            "code" : {
              "coding" : [{
                "system" : "http://fhir.infoway-inforoute.ca/CodeSystem/scpqual",
                "code" : "BD"
              }]
            },
            "period" : {
              "start" : "2000-01-01"
            },
            "issuer" : {
              "reference" : "#grantingInstitution"
            }
          }],
          "communication" : [{
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "2000-01-01"
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
              "valueIdentifier" : {
                "assigner" : {
                  "display" : "MOH"
                }
              }
            }],
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-language-code-system",
              "code" : "B01"
            }]
          }]
        }
      },
      {
        "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/IPC.00147622.BC.PRS",
        "resource" : {
          "resourceType" : "PractitionerRole",
          "id" : "IPC.00147622.BC.PRS",
          "meta" : {
            "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-role"]
          },
          "practitioner" : {
            "identifier" : {
              "extension" : [{
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
                "valueIdentifier" : {
                  "assigner" : {
                    "display" : "MOH"
                  }
                }
              }],
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.00147622.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          },
          "code" : [{
            "coding" : [{
              "system" : "http://fhir.infoway-inforoute.ca/CodeSystem/scptype",
              "code" : "MD"
            }]
          }],
          "specialty" : [{
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "2000-01-01",
                "end" : "2020-01-01"
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-specialty-source-extension",
              "valueString" : "Expertise source"
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
              "valueIdentifier" : {
                "assigner" : {
                  "display" : "MOH"
                }
              }
            }],
            "coding" : [{
              "system" : "http://fhir.infoway-inforoute.ca/CodeSystem/scpqual",
              "code" : "AMD53"
            }]
          }]
        }
      },
      {
        "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/RELN.124.PRS",
        "resource" : {
          "resourceType" : "PractitionerRole",
          "id" : "RELN.124.PRS",
          "meta" : {
            "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-role-relationships"]
          },
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-relationship-type-extension",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system",
                "code" : "EE"
              }]
            }
          },
          {
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
            "valueIdentifier" : {
              "assigner" : {
                "display" : "MOH"
              }
            }
          }],
          "period" : {
            "start" : "2000-01-01"
          },
          "practitioner" : {
            "identifier" : {
              "extension" : [{
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
                "valueIdentifier" : {
                  "assigner" : {
                    "display" : "MOH"
                  }
                }
              }],
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.00147622.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          },
          "organization" : {
            "identifier" : {
              "extension" : [{
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
                "valueIdentifier" : {
                  "assigner" : {
                    "display" : "MOH"
                  }
                }
              }],
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.00147622.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          }
        }
      },
      {
        "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/RELN.126.PRS",
        "resource" : {
          "resourceType" : "PractitionerRole",
          "id" : "RELN.126.PRS",
          "meta" : {
            "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-role-relationships"]
          },
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-location-relationship-type-extension",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system",
                "code" : "WORKSAT"
              }]
            }
          },
          {
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
            "valueIdentifier" : {
              "assigner" : {
                "display" : "MOH"
              }
            }
          }],
          "period" : {
            "start" : "2000-01-01"
          },
          "practitioner" : {
            "identifier" : {
              "extension" : [{
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
                "valueIdentifier" : {
                  "assigner" : {
                    "display" : "MOH"
                  }
                }
              }],
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.00147622.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          },
          "location" : [{
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
              "value" : "IFC.00047422.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          }]
        }
      }]
    }
  },
  {
    "name" : "outcome",
    "resource" : {
      "resourceType" : "OperationOutcome",
      "id" : "Example-OperationOutcome-MaintainSuccess",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-operation-outcome"]
      },
      "issue" : [{
        "severity" : "information",
        "code" : "business-rule",
        "details" : {
          "coding" : [{
            "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-error-code-system",
            "code" : "PRS.PRP.MTN.UNK.0.0.0000"
          }],
          "text" : "The provider transaction was processed."
        }
      }]
    }
  }]
}

```
