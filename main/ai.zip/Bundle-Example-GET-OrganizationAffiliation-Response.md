# Example-GET-OrganizationAffiliation-Response - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-GET-OrganizationAffiliation-Response**

## Example Bundle: Example-GET-OrganizationAffiliation-Response



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Example-GET-OrganizationAffiliation-Response",
  "type" : "searchset",
  "link" : [{
    "relation" : "self",
    "url" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/OrganizationAffiliation/RELN.25.PRS"
  }],
  "entry" : [{
    "fullUrl" : "urn:uuid:3abd58f7-f226-4358-bdfd-2bb64bc93552",
    "resource" : {
      "resourceType" : "OperationOutcome",
      "id" : "Example-OperationOutcome-Success",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-operation-outcome"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"OperationOutcome_Example-OperationOutcome-Success\"> </a><p class=\"res-header-id\"><b>Generated Narrative: OperationOutcome Example-OperationOutcome-Success</b></p><a name=\"Example-OperationOutcome-Success\"> </a><a name=\"hcExample-OperationOutcome-Success\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-operation-outcome.html\">BCOperationOutcome</a></p></div><h3>Issues</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Severity</b></td><td><b>Code</b></td><td><b>Details</b></td></tr><tr><td style=\"display: none\">*</td><td>Information</td><td>Business Rule Violation</td><td><span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-error-code-system PRS.PRP.MTN.UNK.0.0.7067}\">Query successful</span></td></tr></table></div>"
      },
      "issue" : [{
        "severity" : "information",
        "code" : "business-rule",
        "details" : {
          "coding" : [{
            "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-error-code-system",
            "code" : "PRS.PRP.MTN.UNK.0.0.7067"
          }],
          "text" : "Query successful"
        }
      }]
    },
    "search" : {
      "mode" : "outcome"
    }
  },
  {
    "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/OrganizationAffiliation/RELN.25.PRS",
    "resource" : {
      "resourceType" : "OrganizationAffiliation",
      "id" : "RELN.25.PRS",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization-affiliation"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"OrganizationAffiliation_RELN.25.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: OrganizationAffiliation RELN.25.PRS</b></p><a name=\"RELN.25.PRS\"> </a><a name=\"hcRELN.25.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-organization-affiliation.html\">BCOrganizationAffiliation</a></p></div><p><b>period</b>: 2000-01-01 --&gt; (ongoing)</p><p><b>organization</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147436.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>participatingOrganization</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.001164553.BC.PRS (, period: 2000-02-02 --&gt; (ongoing))</p><p><b>code</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system deptof}\">deptof</span></p></div>"
      },
      "period" : {
        "start" : "2000-01-01"
      },
      "organization" : {
        "identifier" : {
          "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
          "value" : "IPC.00147436.BC.PRS",
          "period" : {
            "start" : "2000-01-01"
          }
        }
      },
      "participatingOrganization" : {
        "identifier" : {
          "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
          "value" : "IPC.001164553.BC.PRS",
          "period" : {
            "start" : "2000-02-02"
          }
        }
      },
      "code" : [{
        "coding" : [{
          "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system",
          "code" : "deptof"
        }]
      }]
    },
    "search" : {
      "mode" : "match"
    }
  }]
}

```
