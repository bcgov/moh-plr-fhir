# Example-Request-Update-Practitioner - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-Request-Update-Practitioner**

## Example Parameters: Example-Request-Update-Practitioner



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Example-Request-Update-Practitioner",
  "parameter" : [{
    "name" : "messageId",
    "valueString" : "12344321"
  },
  {
    "name" : "messageTime",
    "valueDateTime" : "2022-06-27T01:01:01-08:00"
  },
  {
    "name" : "maintain",
    "resource" : {
      "resourceType" : "Bundle",
      "id" : "Example-UpdatePractitioner-Bundle",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-bundle"]
      },
      "type" : "collection",
      "entry" : [{
        "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/Practitioner/IPC.00147433.BC.PRS",
        "resource" : {
          "resourceType" : "Practitioner",
          "id" : "IPC.00147433.BC.PRS",
          "meta" : {
            "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner"]
          },
          "extension" : [{
            "extension" : [{
              "url" : "statusCode",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-code-system",
                  "code" : "INACTIVE"
                }]
              }
            },
            {
              "url" : "statusReasonCode",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-reason-code-system",
                  "code" : "LTP"
                }]
              }
            },
            {
              "url" : "statusClassCode",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-class-code-system",
                  "code" : "LIC"
                }]
              }
            },
            {
              "url" : "period",
              "valuePeriod" : {
                "start" : "2022-06-24"
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                  "code" : "CHG"
                }]
              }
            }],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-license-status-extension"
          },
          {
            "extension" : [{
              "url" : "identifier",
              "valueIdentifier" : {
                "value" : "DA-1"
              }
            },
            {
              "url" : "description",
              "valueString" : "Description"
            },
            {
              "url" : "archiveDate",
              "valueDateTime" : "2000-01-01"
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "1998-01-02"
              }
            },
            {
              "url" : "displayFlag",
              "valueBoolean" : false
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                  "code" : "CHG"
                }]
              }
            }],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-disciplinary-action-extension"
          },
          {
            "extension" : [{
              "url" : "identifier",
              "valueIdentifier" : {
                "system" : "http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id",
                "value" : "Note-3"
              }
            },
            {
              "url" : "text",
              "valueString" : "Note text"
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "1998-01-02"
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                  "code" : "CHG"
                }]
              }
            }],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-note-extension"
          },
          {
            "extension" : [{
              "url" : "identifier",
              "valueIdentifier" : {
                "system" : "http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-condition-id",
                "value" : "Condition-2"
              }
            },
            {
              "url" : "restriction",
              "valueBoolean" : false
            },
            {
              "url" : "restrictionText",
              "valueString" : "Restriction text"
            },
            {
              "url" : "code",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-condition-type-code-system",
                  "code" : "EXP"
                }]
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "1998-01-02"
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                  "code" : "CHG"
                }]
              }
            }],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-condition-extension"
          },
          {
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "2000-01-01",
                "end" : "2020-01-01"
              }
            },
            {
              "url" : "code",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
                  "code" : "R"
                }]
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                  "code" : "CEASE"
                }]
              }
            }],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-confidentiality-extension"
          },
          {
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
            "valuePeriod" : {
              "start" : "2012-12-07"
            }
          },
          {
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-birthplace-extension",
            "valueAddress" : {
              "city" : "Ottawa",
              "state" : "ON",
              "country" : "CA"
            }
          },
          {
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                "code" : "CHG"
              }]
            }
          }],
          "identifier" : [{
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
            "value" : "IPC.00147433.BC.PRS",
            "period" : {
              "start" : "2000-01-01"
            }
          }],
          "name" : [{
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                  "code" : "CHG"
                }]
              }
            }],
            "use" : "usual",
            "family" : "FamilyName",
            "given" : ["GivenName"],
            "period" : {
              "start" : "2012-12-07"
            }
          }],
          "telecom" : [{
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                  "code" : "BC"
                }]
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                  "code" : "CHG"
                }]
              }
            }],
            "system" : "phone",
            "value" : "2502222234",
            "period" : {
              "start" : "2000-02-02"
            }
          },
          {
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                  "code" : "BC"
                }]
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                  "code" : "CHG"
                }]
              }
            }],
            "system" : "email",
            "value" : "bob@email.com",
            "period" : {
              "start" : "2000-02-02"
            }
          }],
          "address" : [{
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                  "code" : "BC"
                }]
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                  "code" : "CHG"
                }]
              }
            }],
            "type" : "postal",
            "line" : ["1000 DOUGLAS ST"],
            "city" : "VICTORIA",
            "state" : "BC",
            "postalCode" : "V6P7B8",
            "country" : "CA",
            "period" : {
              "start" : "2000-01-01"
            }
          }],
          "gender" : "male",
          "birthDate" : "1934-01-02",
          "_birthDate" : {
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-birthtime-extension",
              "valueDateTime" : "1951-11-12T00:00:01-06:00"
            }]
          }
        }
      },
      {
        "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/IPC.00147433.BC.PRS",
        "resource" : {
          "resourceType" : "PractitionerRole",
          "id" : "IPC.00147433.BC.PRS",
          "meta" : {
            "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-role"]
          },
          "practitioner" : {
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.00147433.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          },
          "code" : [{
            "coding" : [{
              "system" : "http://fhir.infoway-inforoute.ca/CodeSystem/scptype",
              "code" : "MD"
            }]
          }],
          "specialty" : [{
            "extension" : [{
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "2000-01-01",
                "end" : "2020-01-01"
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-specialty-source-extension",
              "valueString" : "Expertise source"
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                  "code" : "CHG"
                }]
              }
            }],
            "coding" : [{
              "system" : "http://fhir.infoway-inforoute.ca/CodeSystem/scpqual",
              "code" : "AMD53"
            }]
          }]
        }
      },
      {
        "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/RELN.12373.PRS",
        "resource" : {
          "resourceType" : "PractitionerRole",
          "id" : "RELN.12373.PRS",
          "meta" : {
            "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-role-relationships"]
          },
          "extension" : [{
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-relationship-type-extension",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system",
                "code" : "EE"
              }]
            }
          },
          {
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                "code" : "CHG"
              }]
            }
          }],
          "period" : {
            "start" : "2000-01-01"
          },
          "practitioner" : {
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.00147433.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          },
          "organization" : {
            "identifier" : {
              "extension" : [{
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
                "valueIdentifier" : {
                  "assigner" : {
                    "display" : "MOH"
                  }
                }
              }],
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
              "value" : "IPC.00147436.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          }
        }
      }]
    }
  }]
}

```
