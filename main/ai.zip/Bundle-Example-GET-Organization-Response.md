# Example-GET-Organization-Response - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-GET-Organization-Response**

## Example Bundle: Example-GET-Organization-Response



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Example-GET-Organization-Response",
  "type" : "searchset",
  "link" : [{
    "relation" : "self",
    "url" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/Organization/IPC.00047422.BC.PRS"
  }],
  "entry" : [{
    "fullUrl" : "urn:uuid:3abd58f7-f226-4358-bdfd-2bb64bc93552",
    "resource" : {
      "resourceType" : "OperationOutcome",
      "id" : "Example-OperationOutcome-Success",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-operation-outcome"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"OperationOutcome_Example-OperationOutcome-Success\"> </a><p class=\"res-header-id\"><b>Generated Narrative: OperationOutcome Example-OperationOutcome-Success</b></p><a name=\"Example-OperationOutcome-Success\"> </a><a name=\"hcExample-OperationOutcome-Success\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-operation-outcome.html\">BCOperationOutcome</a></p></div><h3>Issues</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Severity</b></td><td><b>Code</b></td><td><b>Details</b></td></tr><tr><td style=\"display: none\">*</td><td>Information</td><td>Business Rule Violation</td><td><span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-error-code-system PRS.PRP.MTN.UNK.0.0.7067}\">Query successful</span></td></tr></table></div>"
      },
      "issue" : [{
        "severity" : "information",
        "code" : "business-rule",
        "details" : {
          "coding" : [{
            "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-error-code-system",
            "code" : "PRS.PRP.MTN.UNK.0.0.7067"
          }],
          "text" : "Query successful"
        }
      }]
    },
    "search" : {
      "mode" : "outcome"
    }
  },
  {
    "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/Organization/IPC.00047422.BC.PRS",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "IPC.00047422.BC.PRS",
      "meta" : {
        "profile" : ["http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_IPC.00047422.BC.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization IPC.00047422.BC.PRS</b></p><a name=\"IPC.00047422.BC.PRS\"> </a><a name=\"hcIPC.00047422.BC.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-organization.html\">BCOrganization</a></p></div><blockquote><p><b>BC Notes Extension</b></p><ul><li>identifier: <code>http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id</code>/Note-2</li><li>text: Note text</li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 1998-01-02 --&gt; (ongoing)</li></ul></blockquote><p><b>identifier</b>: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00047422.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>active</b>: true</p><p><b>name</b>: Kelowna Clinic</p><p><b>alias</b>: ABC Clinic - Kelowna</p><p><b>telecom</b>: ph: 2501112234</p><p><b>address</b>: 1000 DOUGLAS ST Kelowna BC V6P7B8 CA </p></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "identifier",
          "valueIdentifier" : {
            "system" : "http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id",
            "value" : "Note-2"
          }
        },
        {
          "url" : "text",
          "valueString" : "Note text"
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "1998-01-02"
          }
        }],
        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-note-extension"
      }],
      "identifier" : [{
        "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
        "value" : "IPC.00047422.BC.PRS",
        "period" : {
          "start" : "2000-01-01"
        }
      }],
      "active" : true,
      "name" : "Kelowna Clinic",
      "_name" : {
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-name-use-extension",
          "valueCode" : "official"
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
          "valuePeriod" : {
            "start" : "2014-01-31T00:00:00-07:00"
          }
        }]
      },
      "alias" : ["ABC Clinic - Kelowna"],
      "telecom" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
              "code" : "BC"
            }]
          }
        }],
        "system" : "phone",
        "value" : "2501112234",
        "period" : {
          "start" : "2000-02-02"
        }
      }],
      "address" : [{
        "extension" : [{
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
              "code" : "BC"
            }]
          }
        },
        {
          "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-address-validation-status-extension",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-address-validation-status-code-system",
              "code" : "V"
            }]
          }
        }],
        "type" : "postal",
        "line" : ["1000 DOUGLAS ST"],
        "city" : "Kelowna",
        "state" : "BC",
        "postalCode" : "V6P7B8",
        "country" : "CA",
        "period" : {
          "start" : "2000-01-01"
        }
      }]
    },
    "search" : {
      "mode" : "match"
    }
  }]
}

```
