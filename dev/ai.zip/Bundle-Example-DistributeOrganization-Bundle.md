# Example-DistributeOrganization-Bundle - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-DistributeOrganization-Bundle**

## Example Bundle: Example-DistributeOrganization-Bundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Example-DistributeOrganization-Bundle",
  "meta" : {
    "profile" : [
      "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization-bundle"
    ]
  },
  "type" : "collection",
  "entry" : [
    {
      "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/Organization/IPC.00147436.BC.PRS",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "IPC.00147436.BC.PRS",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_IPC.00147436.BC.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization IPC.00147436.BC.PRS</b></p><a name=\"IPC.00147436.BC.PRS\"> </a><a name=\"hcIPC.00147436.BC.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-organization.html\">BCOrganization</a></p></div><blockquote><p><b>BC Notes Extension</b></p><ul><li>identifier: <code>http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id</code>/Note-2</li><li>text: Note text</li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 1998-01-02 --&gt; (ongoing)</li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension: ?ngen-9?</li></ul></blockquote><p><b>identifier</b>: <a href=\"NamingSystem-ca-bc-plr-org-id.html\" title=\"Organization\">CaBcPlrOrgId</a>/123123123 (, period: 2000-01-01 --&gt; (ongoing)), <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147436.BC.PRS (, period: 2000-01-01 --&gt; (ongoing)), <a href=\"NamingSystem-ca-bc-plr-common-party-number.html\" title=\"Common Party Number\">CaBcPlrCommonPartyNumber</a>/CPN.00147433.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-organization-role-code-system CLINIC}\">Clinic</span></p><p><b>name</b>: Kelowna Clinic</p><p><b>alias</b>: ABC Clinic - Kelowna</p><p><b>telecom</b>: ph: 2503424343</p><p><b>address</b>: 19 ST ADDRESS ADDRESSLINE2TXT ADDRESS ADDRESSLINE3TXT VICTORIA BC V6P7B8 CA </p></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "identifier",
                "valueIdentifier" : {
                  "system" : "http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id",
                  "value" : "Note-2"
                }
              },
              {
                "url" : "text",
                "valueString" : "Note text"
              },
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
                "valuePeriod" : {
                  "start" : "1998-01-02"
                }
              },
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
                "valueIdentifier" : {
                  "assigner" : {
                    "display" : "PHSA"
                  }
                }
              }
            ],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-note-extension"
          }
        ],
        "identifier" : [
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
                "valueIdentifier" : {
                  "assigner" : {
                    "display" : "PHSA"
                  }
                }
              }
            ],
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-org-id",
            "value" : "123123123",
            "period" : {
              "start" : "2000-01-01"
            }
          },
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
                "valueIdentifier" : {
                  "assigner" : {
                    "display" : "MOH"
                  }
                }
              }
            ],
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
            "value" : "IPC.00147436.BC.PRS",
            "period" : {
              "start" : "2000-01-01"
            }
          },
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
                "valueIdentifier" : {
                  "assigner" : {
                    "display" : "PHSA"
                  }
                }
              }
            ],
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-common-party-number",
            "value" : "CPN.00147433.BC.PRS",
            "period" : {
              "start" : "2000-01-01"
            }
          }
        ],
        "active" : true,
        "type" : [
          {
            "coding" : [
              {
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-organization-role-code-system",
                "code" : "CLINIC"
              }
            ]
          }
        ],
        "name" : "Kelowna Clinic",
        "_name" : {
          "extension" : [
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-name-use-extension",
              "valueCode" : "official"
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "2014-01-31T00:00:00-07:00"
              }
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
              "valueIdentifier" : {
                "assigner" : {
                  "display" : "PHSA"
                }
              }
            }
          ]
        },
        "alias" : ["ABC Clinic - Kelowna"],
        "telecom" : [
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                      "code" : "BC"
                    }
                  ]
                }
              },
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
                "valueIdentifier" : {
                  "assigner" : {
                    "display" : "PHSA"
                  }
                }
              }
            ],
            "system" : "phone",
            "value" : "2503424343",
            "period" : {
              "start" : "2000-02-02"
            }
          }
        ],
        "address" : [
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                      "code" : "BC"
                    }
                  ]
                }
              },
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-address-validation-status-extension",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-address-validation-status-code-system",
                      "code" : "V"
                    }
                  ]
                }
              },
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
                "valueIdentifier" : {
                  "assigner" : {
                    "display" : "PHSA"
                  }
                }
              }
            ],
            "type" : "postal",
            "line" : ["19 ST", "ADDRESS ADDRESSLINE2TXT", "ADDRESS ADDRESSLINE3TXT"],
            "city" : "VICTORIA",
            "state" : "BC",
            "postalCode" : "V6P7B8",
            "country" : "CA",
            "period" : {
              "start" : "2000-01-01"
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/RELN.123.PRS",
      "resource" : {
        "resourceType" : "PractitionerRole",
        "id" : "RELN.123.PRS",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-role-relationships"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_RELN.123.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole RELN.123.PRS</b></p><a name=\"RELN.123.PRS\"> </a><a name=\"hcRELN.123.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-role-relationships.html\">BCRoleRelationships</a></p></div><p><b>BC Practitioner to Organization or Practitioner to Practitioner Type Extension.</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system EE}\">Employee</span></p><p><b>period</b>: 2000-01-01 --&gt; (ongoing)</p><p><b>practitioner</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147422.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>organization</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147436.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p></div>"
        },
        "extension" : [
          {
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-relationship-type-extension",
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system",
                  "code" : "EE"
                }
              ]
            }
          }
        ],
        "period" : {
          "start" : "2000-01-01"
        },
        "practitioner" : {
          "identifier" : {
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
            "value" : "IPC.00147422.BC.PRS",
            "period" : {
              "start" : "2000-01-01"
            }
          }
        },
        "organization" : {
          "identifier" : {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
                "valueIdentifier" : {
                  "assigner" : {
                    "display" : "MOH"
                  }
                }
              }
            ],
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
            "value" : "IPC.00147436.BC.PRS",
            "period" : {
              "start" : "2000-01-01"
            }
          }
        }
      }
    },
    {
      "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/OrganizationAffiliation/RELN.132.PRS",
      "resource" : {
        "resourceType" : "OrganizationAffiliation",
        "id" : "RELN.132.PRS",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization-affiliation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"OrganizationAffiliation_RELN.132.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: OrganizationAffiliation RELN.132.PRS</b></p><a name=\"RELN.132.PRS\"> </a><a name=\"hcRELN.132.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-organization-affiliation.html\">BCOrganizationAffiliation</a></p></div><p><b>period</b>: 2000-01-01 --&gt; (ongoing)</p><p><b>organization</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147436.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>code</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system operatesfrom}\">operatesfrom</span></p><p><b>location</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ifc.html\" title=\"Internal Facility Code\">CaBcPlrIfc</a>/IFC.00047422.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p></div>"
        },
        "period" : {
          "start" : "2000-01-01"
        },
        "organization" : {
          "identifier" : {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
                "valueIdentifier" : {
                  "assigner" : {
                    "display" : "MOH"
                  }
                }
              }
            ],
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
            "value" : "IPC.00147436.BC.PRS",
            "period" : {
              "start" : "2000-01-01"
            }
          }
        },
        "code" : [
          {
            "coding" : [
              {
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system",
                "code" : "operatesfrom"
              }
            ]
          }
        ],
        "location" : [
          {
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
              "value" : "IFC.00047422.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          }
        ]
      }
    }
  ]
}

```
