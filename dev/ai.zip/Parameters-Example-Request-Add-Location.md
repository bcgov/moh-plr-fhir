# Example-Request-Add-Location - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-Request-Add-Location**

## Example Parameters: Example-Request-Add-Location



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Example-Request-Add-Location",
  "parameter" : [
    {
      "name" : "messageId",
      "valueString" : "12344321"
    },
    {
      "name" : "messageTime",
      "valueDateTime" : "2022-06-27T01:01:01-08:00"
    },
    {
      "name" : "maintain",
      "resource" : {
        "resourceType" : "Bundle",
        "id" : "Example-AddLocationWithLinks-Bundle",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-location-bundle"
          ]
        },
        "type" : "collection",
        "entry" : [
          {
            "fullUrl" : "urn:uuid:18734433-5c7b-42c8-ade5-22bd2c82e4f2",
            "resource" : {
              "resourceType" : "Location",
              "id" : "Example-Location-For-Add",
              "meta" : {
                "profile" : [
                  "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-location"
                ]
              },
              "extension" : [
                {
                  "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-physical-address-extension",
                  "valueAddress" : {
                    "extension" : [
                      {
                        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
                        "valueCodeableConcept" : {
                          "coding" : [
                            {
                              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                              "code" : "FC"
                            }
                          ]
                        }
                      }
                    ],
                    "type" : "physical",
                    "line" : ["1000 DOUGLAS ST"],
                    "city" : "VICTORIA",
                    "state" : "BC",
                    "postalCode" : "V6P7B8",
                    "country" : "CA",
                    "period" : {
                      "start" : "2000-01-01"
                    }
                  }
                },
                {
                  "extension" : [
                    {
                      "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
                      "valuePeriod" : {
                        "start" : "2000-01-01"
                      }
                    }
                  ],
                  "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-details-extension"
                }
              ],
              "identifier" : [
                {
                  "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
                  "value" : "IFC.001474222.BC.PRS",
                  "period" : {
                    "start" : "2000-01-01"
                  }
                }
              ],
              "name" : "General Hospital",
              "_name" : {
                "extension" : [
                  {
                    "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
                    "valuePeriod" : {
                      "start" : "2000-01-01"
                    }
                  }
                ]
              },
              "alias" : ["Long name or alias or description"],
              "telecom" : [
                {
                  "extension" : [
                    {
                      "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
                      "valueCodeableConcept" : {
                        "coding" : [
                          {
                            "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                            "code" : "FC"
                          }
                        ]
                      }
                    }
                  ],
                  "system" : "fax",
                  "value" : "55555555551",
                  "period" : {
                    "start" : "1982-03-04T00:00:00-07:00"
                  }
                }
              ],
              "address" : {
                "extension" : [
                  {
                    "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
                    "valueCodeableConcept" : {
                      "coding" : [
                        {
                          "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                          "code" : "FC"
                        }
                      ]
                    }
                  }
                ],
                "type" : "physical",
                "line" : ["1000 DOUGLAS ST"],
                "city" : "VICTORIA",
                "state" : "BC",
                "postalCode" : "V6P7B8",
                "country" : "CA",
                "period" : {
                  "start" : "2000-01-01"
                }
              },
              "physicalType" : {
                "coding" : [
                  {
                    "system" : "http://terminology.hl7.org/CodeSystem/location-physical-type",
                    "code" : "bu"
                  }
                ]
              }
            }
          },
          {
            "fullUrl" : "urn:uuid:162587c8-eb05-40be-a3a2-ca16d52f73b3",
            "resource" : {
              "resourceType" : "OrganizationAffiliation",
              "id" : "Example-OrganizationAffiliation-Loc1",
              "meta" : {
                "profile" : [
                  "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization-affiliation"
                ]
              },
              "period" : {
                "start" : "2000-01-01"
              },
              "organization" : {
                "identifier" : {
                  "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
                  "value" : "IPC.70007000.PRS.BC",
                  "period" : {
                    "start" : "2000-01-01"
                  }
                }
              },
              "code" : [
                {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system",
                      "code" : "OPERATES"
                    }
                  ]
                }
              ],
              "location" : [
                {
                  "identifier" : {
                    "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
                    "value" : "IFC.001474222.BC.PRS",
                    "period" : {
                      "start" : "2000-01-01"
                    }
                  }
                }
              ]
            }
          },
          {
            "fullUrl" : "urn:uuid:809e0074-ded0-11ed-b5ea-0242ac120002",
            "resource" : {
              "resourceType" : "OrganizationAffiliation",
              "id" : "Example-OrganizationAffiliation-Loc2",
              "meta" : {
                "profile" : [
                  "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization-affiliation"
                ]
              },
              "period" : {
                "start" : "2000-01-01"
              },
              "organization" : {
                "identifier" : {
                  "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
                  "value" : "IPC.90009000.PRS.BC",
                  "period" : {
                    "start" : "2000-01-01"
                  }
                }
              },
              "code" : [
                {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system",
                      "code" : "OWNS"
                    }
                  ]
                }
              ],
              "location" : [
                {
                  "identifier" : {
                    "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
                    "value" : "IFC.001474222.BC.PRS",
                    "period" : {
                      "start" : "2000-01-01"
                    }
                  }
                }
              ]
            }
          },
          {
            "fullUrl" : "urn:uuid:ef046dcc-7ebe-401b-b44e-594ed21bed81",
            "resource" : {
              "resourceType" : "PractitionerRole",
              "id" : "Example-PractitionerRole-Loc3",
              "meta" : {
                "profile" : [
                  "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-role-relationships"
                ]
              },
              "extension" : [
                {
                  "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-location-relationship-type-extension",
                  "valueCodeableConcept" : {
                    "coding" : [
                      {
                        "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system",
                        "code" : "PRACTICES_AT"
                      }
                    ]
                  }
                }
              ],
              "period" : {
                "start" : "2000-01-01"
              },
              "practitioner" : {
                "identifier" : {
                  "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
                  "value" : "IPC.80008000.PRS.BC",
                  "period" : {
                    "start" : "2000-01-01"
                  }
                }
              },
              "location" : [
                {
                  "identifier" : {
                    "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
                    "value" : "IFC.001474222.BC.PRS",
                    "period" : {
                      "start" : "2000-01-01"
                    }
                  }
                }
              ]
            }
          }
        ]
      }
    }
  ]
}

```
