# Example-AddLocation-Bundle - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-AddLocation-Bundle**

## Example Bundle: Example-AddLocation-Bundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Example-AddLocation-Bundle",
  "meta" : {
    "profile" : [
      "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-location-bundle"
    ]
  },
  "type" : "collection",
  "entry" : [
    {
      "fullUrl" : "urn:uuid:18734433-5c7b-42c8-ade5-22bd2c82e4f2",
      "resource" : {
        "resourceType" : "Location",
        "id" : "Example-Location-For-Add",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-location"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Location_Example-Location-For-Add\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Location Example-Location-For-Add</b></p><a name=\"Example-Location-For-Add\"> </a><a name=\"hcExample-Location-For-Add\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-location.html\">BCLocation</a></p></div><p><b>BC Facility Physical Address Extension</b>: 1000 DOUGLAS ST VICTORIA BC V6P7B8 CA </p><blockquote><p><b>BC Facility Details Extension</b></p><ul><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 2000-01-01 --&gt; (ongoing)</li></ul></blockquote><p><b>identifier</b>: <a href=\"NamingSystem-ca-bc-plr-ifc.html\" title=\"Internal Facility Code\">CaBcPlrIfc</a>/IFC.001474222.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>name</b>: General Hospital</p><p><b>alias</b>: Long name or alias or description</p><p><b>telecom</b>: fax: 55555555551</p><p><b>address</b>: 1000 DOUGLAS ST VICTORIA BC V6P7B8 CA </p><p><b>physicalType</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/location-physical-type bu}\">Building</span></p></div>"
        },
        "extension" : [
          {
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-physical-address-extension",
            "valueAddress" : {
              "extension" : [
                {
                  "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
                  "valueCodeableConcept" : {
                    "coding" : [
                      {
                        "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                        "code" : "FC"
                      }
                    ]
                  }
                }
              ],
              "type" : "physical",
              "line" : ["1000 DOUGLAS ST"],
              "city" : "VICTORIA",
              "state" : "BC",
              "postalCode" : "V6P7B8",
              "country" : "CA",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          },
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
                "valuePeriod" : {
                  "start" : "2000-01-01"
                }
              }
            ],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-details-extension"
          }
        ],
        "identifier" : [
          {
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
            "value" : "IFC.001474222.BC.PRS",
            "period" : {
              "start" : "2000-01-01"
            }
          }
        ],
        "name" : "General Hospital",
        "_name" : {
          "extension" : [
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "2000-01-01"
              }
            }
          ]
        },
        "alias" : ["Long name or alias or description"],
        "telecom" : [
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                      "code" : "FC"
                    }
                  ]
                }
              }
            ],
            "system" : "fax",
            "value" : "55555555551",
            "period" : {
              "start" : "1982-03-04T00:00:00-07:00"
            }
          }
        ],
        "address" : {
          "extension" : [
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
              "valueCodeableConcept" : {
                "coding" : [
                  {
                    "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                    "code" : "FC"
                  }
                ]
              }
            }
          ],
          "type" : "physical",
          "line" : ["1000 DOUGLAS ST"],
          "city" : "VICTORIA",
          "state" : "BC",
          "postalCode" : "V6P7B8",
          "country" : "CA",
          "period" : {
            "start" : "2000-01-01"
          }
        },
        "physicalType" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/location-physical-type",
              "code" : "bu"
            }
          ]
        }
      }
    }
  ]
}

```
