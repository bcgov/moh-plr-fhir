# Example-Organizational-Provider-Bundle - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-Organizational-Provider-Bundle**

## Example Bundle: Example-Organizational-Provider-Bundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Example-Organizational-Provider-Bundle",
  "meta" : {
    "profile" : [
      "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization-bundle"
    ]
  },
  "type" : "collection",
  "timestamp" : "2022-02-02T13:23:13.000-08:00",
  "entry" : [
    {
      "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/Organization/IPC.00147437.BC.PRS",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "IPC.00147437.BC.PRS",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_IPC.00147437.BC.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization IPC.00147437.BC.PRS</b></p><a name=\"IPC.00147437.BC.PRS\"> </a><a name=\"hcIPC.00147437.BC.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-organization.html\">BCOrganization</a></p></div><blockquote><p><b>BC Notes Extension</b></p><ul><li>identifier: <code>http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id</code>/Note-2</li><li>text: Note text</li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 1998-01-02 --&gt; (ongoing)</li></ul></blockquote><blockquote><p><b>BC License Status Extension</b></p><ul><li>statusCode: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleStatus active}\">active</span></li><li>period: 2022-02-07 --&gt; 2023-02-07</li><li>statusReasonCode: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-reason-code-system ORG}\">Organization Provider</span></li><li>statusClassCode: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-class-code-system AE}\">Assigned Entity</span></li></ul></blockquote><p><b>identifier</b>: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147437.BC.PRS (, period: 2000-01-01 --&gt; (ongoing)), <a href=\"NamingSystem-ca-bc-plr-common-party-number.html\" title=\"Common Party Number\">CaBcPlrCommonPartyNumber</a>/CPN.00147422.BC.PRS (, period: 2000-01-01 --&gt; (ongoing)), <a href=\"NamingSystem-ca-bc-plr-org-id.html\" title=\"Organization\">CaBcPlrOrgId</a>/123123123 (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>type</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-organization-role-code-system ORG}\">Organization</span></p><p><b>name</b>: ABC Clinic</p><p><b>alias</b>: ABC Clinic - Kelowna</p><p><b>telecom</b>: ph: 2501112234</p><p><b>address</b>: 1000 DOUGLAS ST Kelowna BC V6P7B8 CA </p></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "identifier",
                "valueIdentifier" : {
                  "system" : "http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id",
                  "value" : "Note-2"
                }
              },
              {
                "url" : "text",
                "valueString" : "Note text"
              },
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
                "valuePeriod" : {
                  "start" : "1998-01-02"
                }
              }
            ],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-note-extension"
          },
          {
            "extension" : [
              {
                "url" : "statusCode",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleStatus",
                      "code" : "active"
                    }
                  ]
                }
              },
              {
                "url" : "period",
                "valuePeriod" : {
                  "start" : "2022-02-07",
                  "end" : "2023-02-07"
                }
              },
              {
                "url" : "statusReasonCode",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-reason-code-system",
                      "code" : "ORG"
                    }
                  ]
                }
              },
              {
                "url" : "statusClassCode",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-class-code-system",
                      "code" : "AE"
                    }
                  ]
                }
              }
            ],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-license-status-extension"
          }
        ],
        "identifier" : [
          {
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
            "value" : "IPC.00147437.BC.PRS",
            "period" : {
              "start" : "2000-01-01"
            }
          },
          {
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-common-party-number",
            "value" : "CPN.00147422.BC.PRS",
            "period" : {
              "start" : "2000-01-01"
            }
          },
          {
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-org-id",
            "value" : "123123123",
            "period" : {
              "start" : "2000-01-01"
            }
          }
        ],
        "type" : [
          {
            "coding" : [
              {
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-organization-role-code-system",
                "code" : "ORG"
              }
            ]
          }
        ],
        "name" : "ABC Clinic",
        "_name" : {
          "extension" : [
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-name-use-extension",
              "valueCode" : "official"
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "2000-01-01",
                "end" : "2022-09-01"
              }
            }
          ]
        },
        "alias" : ["ABC Clinic - Kelowna"],
        "telecom" : [
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                      "code" : "BC"
                    }
                  ]
                }
              }
            ],
            "system" : "phone",
            "value" : "2501112234",
            "period" : {
              "start" : "2000-02-02"
            }
          }
        ],
        "address" : [
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                      "code" : "BC"
                    }
                  ]
                }
              },
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-address-validation-status-extension",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-address-validation-status-code-system",
                      "code" : "V"
                    }
                  ]
                }
              }
            ],
            "type" : "postal",
            "line" : ["1000 DOUGLAS ST"],
            "city" : "Kelowna",
            "state" : "BC",
            "postalCode" : "V6P7B8",
            "country" : "CA",
            "period" : {
              "start" : "2000-01-01"
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/RELN.127.PRS",
      "resource" : {
        "resourceType" : "PractitionerRole",
        "id" : "RELN.127.PRS",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-role-relationships"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_RELN.127.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole RELN.127.PRS</b></p><a name=\"RELN.127.PRS\"> </a><a name=\"hcRELN.127.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-role-relationships.html\">BCRoleRelationships</a></p></div><p><b>BC Practitioner to Organization or Practitioner to Practitioner Type Extension.</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system careteam}\">careteam</span></p><p><b>period</b>: 2000-01-01 --&gt; (ongoing)</p><p><b>practitioner</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147422.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>organization</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147437.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p></div>"
        },
        "extension" : [
          {
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-relationship-type-extension",
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system",
                  "code" : "careteam"
                }
              ]
            }
          }
        ],
        "period" : {
          "start" : "2000-01-01"
        },
        "practitioner" : {
          "identifier" : {
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
            "value" : "IPC.00147422.BC.PRS",
            "period" : {
              "start" : "2000-01-01"
            }
          }
        },
        "organization" : {
          "identifier" : {
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
            "value" : "IPC.00147437.BC.PRS",
            "period" : {
              "start" : "2000-01-01"
            }
          }
        }
      }
    },
    {
      "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/OrganizationAffiliation/RELN.141.PRS",
      "resource" : {
        "resourceType" : "OrganizationAffiliation",
        "id" : "RELN.141.PRS",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization-affiliation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"OrganizationAffiliation_RELN.141.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: OrganizationAffiliation RELN.141.PRS</b></p><a name=\"RELN.141.PRS\"> </a><a name=\"hcRELN.141.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-organization-affiliation.html\">BCOrganizationAffiliation</a></p></div><p><b>period</b>: 2000-01-01 --&gt; (ongoing)</p><p><b>organization</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147437.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>participatingOrganization</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.001164553.BC.PRS (, period: 2000-02-02 --&gt; (ongoing))</p><p><b>code</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system deptof}\">deptof</span></p></div>"
        },
        "period" : {
          "start" : "2000-01-01"
        },
        "organization" : {
          "identifier" : {
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
            "value" : "IPC.00147437.BC.PRS",
            "period" : {
              "start" : "2000-01-01"
            }
          }
        },
        "participatingOrganization" : {
          "identifier" : {
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
            "value" : "IPC.001164553.BC.PRS",
            "period" : {
              "start" : "2000-02-02"
            }
          }
        },
        "code" : [
          {
            "coding" : [
              {
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-relationship-type-code-system",
                "code" : "deptof"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/OrganizationAffiliation/RELN.142.PRS",
      "resource" : {
        "resourceType" : "OrganizationAffiliation",
        "id" : "RELN.142.PRS",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization-affiliation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"OrganizationAffiliation_RELN.142.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: OrganizationAffiliation RELN.142.PRS</b></p><a name=\"RELN.142.PRS\"> </a><a name=\"hcRELN.142.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-organization-affiliation.html\">BCOrganizationAffiliation</a></p></div><p><b>period</b>: 2000-01-01 --&gt; (ongoing)</p><p><b>organization</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00147437.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>code</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system operatesfrom}\">operatesfrom</span></p><p><b>location</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ifc.html\" title=\"Internal Facility Code\">CaBcPlrIfc</a>/IFC.00047422.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p></div>"
        },
        "period" : {
          "start" : "2000-01-01"
        },
        "organization" : {
          "identifier" : {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-owner-extension",
                "valueIdentifier" : {
                  "assigner" : {
                    "display" : "MOH"
                  }
                }
              }
            ],
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
            "value" : "IPC.00147437.BC.PRS",
            "period" : {
              "start" : "2000-01-01"
            }
          }
        },
        "code" : [
          {
            "coding" : [
              {
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-location-relationship-type-code-system",
                "code" : "operatesfrom"
              }
            ]
          }
        ],
        "location" : [
          {
            "identifier" : {
              "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
              "value" : "IFC.00047422.BC.PRS",
              "period" : {
                "start" : "2000-01-01"
              }
            }
          }
        ]
      }
    }
  ]
}

```
