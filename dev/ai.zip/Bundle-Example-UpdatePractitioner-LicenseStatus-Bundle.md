# Example-UpdatePractitioner-LicenseStatus-Bundle - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-UpdatePractitioner-LicenseStatus-Bundle**

## Example Bundle: Example-UpdatePractitioner-LicenseStatus-Bundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Example-UpdatePractitioner-LicenseStatus-Bundle",
  "meta" : {
    "profile" : [
      "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-bundle"
    ]
  },
  "type" : "collection",
  "entry" : [
    {
      "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/Practitioner/IPC.00763481.BC.PRS",
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "IPC.00763481.BC.PRS",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_IPC.00763481.BC.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner IPC.00763481.BC.PRS</b></p><a name=\"IPC.00763481.BC.PRS\"> </a><a name=\"hcIPC.00763481.BC.PRS\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-practitioner.html\">BCPractitioner</a></p></div><blockquote><p><b>BC License Status Extension</b></p><ul><li>statusCode: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-code-system INACTIVE}\">Inactive</span></li><li>statusReasonCode: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-reason-code-system LTP}\">Left the Province</span></li><li>statusClassCode: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-class-code-system LIC}\">Licensure</span></li><li>period: 2022-06-24 --&gt; (ongoing)</li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system CHG}\">Change</span></li></ul></blockquote><p><b>identifier</b>: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00763481.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>name</b>: null </p></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "statusCode",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-code-system",
                      "code" : "INACTIVE"
                    }
                  ]
                }
              },
              {
                "url" : "statusReasonCode",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-reason-code-system",
                      "code" : "LTP"
                    }
                  ]
                }
              },
              {
                "url" : "statusClassCode",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-class-code-system",
                      "code" : "LIC"
                    }
                  ]
                }
              },
              {
                "url" : "period",
                "valuePeriod" : {
                  "start" : "2022-06-24"
                }
              },
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-end-reason-extension",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-end-reason-code-system",
                      "code" : "CHG"
                    }
                  ]
                }
              }
            ],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-license-status-extension"
          }
        ],
        "identifier" : [
          {
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
            "value" : "IPC.00763481.BC.PRS",
            "period" : {
              "start" : "2000-01-01"
            }
          }
        ],
        "name" : [
          {
            "_family" : {
              "extension" : [
                {
                  "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
                  "valueCode" : "not-applicable"
                }
              ]
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "https://plresb.hlth.gov.bc.ca/HSA-web/fhir-rs/PractitionerRole/IPC.00763481.BC.PRS",
      "resource" : {
        "resourceType" : "PractitionerRole",
        "id" : "IPC.00763481.BC.PRS",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-practitioner-role"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_IPC.00763481.BC.PRS\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole IPC.00763481.BC.PRS</b></p><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-practitioner-role.html\">BCPractitionerRole</a></p></div><p><b>practitioner</b>: Identifier: <a href=\"NamingSystem-ca-bc-plr-ipc.html\" title=\"Internal Party Code\">CaBcPlrIpc</a>/IPC.00763481.BC.PRS (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>code</b>: <span title=\"Codes:{http://fhir.infoway-inforoute.ca/CodeSystem/scptype MD}\">MD</span></p></div>"
        },
        "practitioner" : {
          "identifier" : {
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ipc",
            "value" : "IPC.00763481.BC.PRS",
            "period" : {
              "start" : "2000-01-01"
            }
          }
        },
        "code" : [
          {
            "coding" : [
              {
                "system" : "http://fhir.infoway-inforoute.ca/CodeSystem/scptype",
                "code" : "MD"
              }
            ]
          }
        ]
      }
    }
  ]
}

```
