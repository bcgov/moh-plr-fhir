# Example-AddOrganization-Bundle - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-AddOrganization-Bundle**

## Example Bundle: Example-AddOrganization-Bundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Example-AddOrganization-Bundle",
  "meta" : {
    "profile" : [
      "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization-bundle"
    ]
  },
  "type" : "collection",
  "entry" : [
    {
      "fullUrl" : "urn:uuid:e24cfa57-5e07-4e5b-b229-0e65c74de7bf",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "Example-Organization-1",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-organization"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_Example-Organization-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization Example-Organization-1</b></p><a name=\"Example-Organization-1\"> </a><a name=\"hcExample-Organization-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-bc-organization.html\">BCOrganization</a></p></div><blockquote><p><b>BC Notes Extension</b></p><ul><li>identifier: <code>http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id</code>/Note-2</li><li>text: Note text</li><li>http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension: 1998-01-02 --&gt; (ongoing)</li></ul></blockquote><blockquote><p><b>BC License Status Extension</b></p><ul><li>statusCode: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleStatus active}\">active</span></li><li>period: 2022-02-07 --&gt; 2023-12-07</li><li>statusReasonCode: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-reason-code-system ORG}\">Organization Provider</span></li><li>statusClassCode: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-class-code-system AE}\">Assigned Entity</span></li></ul></blockquote><p><b>identifier</b>: <a href=\"NamingSystem-ca-bc-plr-org-id.html\" title=\"Organization\">CaBcPlrOrgId</a>/123123123 (, period: 2000-01-01 --&gt; (ongoing))</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-organization-role-code-system ORG}\">Organization</span></p><p><b>name</b>: Kelowna Clinic</p><p><b>alias</b>: ABC Clinic - Kelowna</p><p><b>telecom</b>: ph: 2501112234</p><p><b>address</b>: 1000 DOUGLAS ST Kelowna BC V6P7B8 CA </p></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "identifier",
                "valueIdentifier" : {
                  "system" : "http://hlth.gov.bc.ca/fhir/provider/identifier-system/bc-note-id",
                  "value" : "Note-2"
                }
              },
              {
                "url" : "text",
                "valueString" : "Note text"
              },
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
                "valuePeriod" : {
                  "start" : "1998-01-02"
                }
              }
            ],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-note-extension"
          },
          {
            "extension" : [
              {
                "url" : "statusCode",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleStatus",
                      "code" : "active"
                    }
                  ]
                }
              },
              {
                "url" : "period",
                "valuePeriod" : {
                  "start" : "2022-02-07",
                  "end" : "2023-12-07"
                }
              },
              {
                "url" : "statusReasonCode",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-reason-code-system",
                      "code" : "ORG"
                    }
                  ]
                }
              },
              {
                "url" : "statusClassCode",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-license-status-class-code-system",
                      "code" : "AE"
                    }
                  ]
                }
              }
            ],
            "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-license-status-extension"
          }
        ],
        "identifier" : [
          {
            "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-org-id",
            "value" : "123123123",
            "period" : {
              "start" : "2000-01-01"
            }
          }
        ],
        "active" : true,
        "type" : [
          {
            "coding" : [
              {
                "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-organization-role-code-system",
                "code" : "ORG"
              }
            ]
          }
        ],
        "name" : "Kelowna Clinic",
        "_name" : {
          "extension" : [
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-name-use-extension",
              "valueCode" : "official"
            },
            {
              "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
              "valuePeriod" : {
                "start" : "2014-01-31T00:00:00-07:00"
              }
            }
          ]
        },
        "alias" : ["ABC Clinic - Kelowna"],
        "telecom" : [
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                      "code" : "BC"
                    }
                  ]
                }
              }
            ],
            "system" : "phone",
            "value" : "2501112234",
            "period" : {
              "start" : "2000-02-02"
            }
          }
        ],
        "address" : [
          {
            "extension" : [
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                      "code" : "BC"
                    }
                  ]
                }
              },
              {
                "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-address-validation-status-extension",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-address-validation-status-code-system",
                      "code" : "V"
                    }
                  ]
                }
              }
            ],
            "type" : "postal",
            "line" : ["1000 DOUGLAS ST"],
            "city" : "Kelowna",
            "state" : "BC",
            "postalCode" : "V6P7B8",
            "country" : "CA",
            "period" : {
              "start" : "2000-01-01"
            }
          }
        ]
      }
    }
  ]
}

```
