# Example-Response-Add-Location - BC Provider Location Registry FHIR Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-Response-Add-Location**

## Example Parameters: Example-Response-Add-Location



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Example-Response-Add-Location",
  "parameter" : [
    {
      "name" : "messageId",
      "valueString" : "902834987234"
    },
    {
      "name" : "messageTime",
      "valueDateTime" : "2022-06-27T01:01:01-08:00"
    },
    {
      "name" : "maintain",
      "resource" : {
        "resourceType" : "Bundle",
        "id" : "Example-AddLocationWithLinks-Bundle-Response",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-location-bundle"
          ]
        },
        "type" : "collection",
        "entry" : [
          {
            "fullUrl" : "urn:uuid:18734433-5c7b-42c8-ade5-22bd2c82e4f2",
            "resource" : {
              "resourceType" : "Location",
              "id" : "IFC.00147423.BC.PRS",
              "meta" : {
                "profile" : [
                  "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-location"
                ]
              },
              "extension" : [
                {
                  "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-physical-address-extension",
                  "valueAddress" : {
                    "extension" : [
                      {
                        "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
                        "valueCodeableConcept" : {
                          "coding" : [
                            {
                              "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                              "code" : "FC"
                            }
                          ]
                        }
                      }
                    ],
                    "type" : "physical",
                    "line" : ["1000 DOUGLAS ST"],
                    "city" : "VICTORIA",
                    "state" : "BC",
                    "postalCode" : "V6P7B8",
                    "country" : "CA",
                    "period" : {
                      "start" : "2000-01-01"
                    }
                  }
                },
                {
                  "extension" : [
                    {
                      "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
                      "valuePeriod" : {
                        "start" : "2000-01-01"
                      }
                    }
                  ],
                  "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-details-extension"
                },
                {
                  "extension" : [
                    {
                      "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-health-authority-extension",
                      "valueString" : "Vancouver Island"
                    },
                    {
                      "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-health-service-delivery-area-extension",
                      "valueString" : "South Vancouver Island"
                    },
                    {
                      "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-local-health-area-extension",
                      "valueString" : "Greater Victoria"
                    },
                    {
                      "extension" : [
                        {
                          "url" : "name",
                          "valueString" : "Downtown Victoria/Vic West"
                        },
                        {
                          "url" : "code",
                          "valueIdentifier" : {
                            "value" : "4111"
                          }
                        }
                      ],
                      "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-community-health-area-extension"
                    },
                    {
                      "extension" : [
                        {
                          "url" : "name",
                          "valueString" : "Downtown/VicWest"
                        },
                        {
                          "url" : "code",
                          "valueIdentifier" : {
                            "value" : "40701"
                          }
                        }
                      ],
                      "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-primary-care-network-extension"
                    }
                  ],
                  "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-facility-health-service-area-extension"
                }
              ],
              "identifier" : [
                {
                  "system" : "https://health.gov.bc.ca/fhir/NamingSystem/ca-bc-plr-ifc",
                  "value" : "IFC.00147423.BC.PRS",
                  "period" : {
                    "start" : "2000-01-01"
                  }
                }
              ],
              "name" : "General Hospital",
              "_name" : {
                "extension" : [
                  {
                    "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-period-extension",
                    "valuePeriod" : {
                      "start" : "2000-01-01"
                    }
                  }
                ]
              },
              "alias" : ["Long name or alias or description"],
              "telecom" : [
                {
                  "extension" : [
                    {
                      "url" : "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-communication-purpose-code-extension",
                      "valueCodeableConcept" : {
                        "coding" : [
                          {
                            "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-communication-purpose-code-system",
                            "code" : "FC"
                          }
                        ]
                      }
                    }
                  ],
                  "system" : "fax",
                  "value" : "55555555551",
                  "period" : {
                    "start" : "1982-03-04T00:00:00-07:00"
                  }
                }
              ],
              "physicalType" : {
                "coding" : [
                  {
                    "system" : "http://terminology.hl7.org/CodeSystem/location-physical-type",
                    "code" : "bu"
                  }
                ]
              }
            }
          }
        ]
      }
    },
    {
      "name" : "outcome",
      "resource" : {
        "resourceType" : "OperationOutcome",
        "id" : "Example-OperationOutcome-MaintainSuccess",
        "meta" : {
          "profile" : [
            "http://hlth.gov.bc.ca/fhir/provider/StructureDefinition/bc-operation-outcome"
          ]
        },
        "issue" : [
          {
            "severity" : "information",
            "code" : "business-rule",
            "details" : {
              "coding" : [
                {
                  "system" : "https://terminology.hlth.gov.bc.ca/ProviderLocationRegistry/CodeSystem/bc-error-code-system",
                  "code" : "PRS.PRP.MTN.UNK.0.0.0000"
                }
              ],
              "text" : "The provider transaction was processed."
            }
          }
        ]
      }
    }
  ]
}

```
