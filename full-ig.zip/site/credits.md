{% raw %}
<blockquote class="stu-note">
<p>
This specification is currently published as a Draft Standard on the ministry github and is not intended for implementation.  Feedback is welcome but readers should understand that there is more work to be done in testing the profiles and operations defined in this guide.  For more information, please see the <a href="future.html">Future Plans</a> page in this guide.</p>
</blockquote>
{% endraw %}

This specification was written and built by:

* BC Ministry of Health (Khushwinder Sekhon)
* CGI (Jonathan Wiebe, Linda Woo, Neil Shrimpton)
* Constable Consulting (Lorraine Constable)
* Duteau Design (Jean Duteau)
